import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '30mb' }));

// Initializing GoogleGenAI client with required aistudio-build header
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Primary fast supported model from gemini-api skill
const PRIMARY_MODEL = 'gemini-3.1-flash-lite';
const FALLBACK_MODEL = 'gemini-flash-latest';

// Health check endpoint
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    appName: 'BIJOY AI',
    primaryModel: PRIMARY_MODEL,
    hasApiKey: !!process.env.GEMINI_API_KEY,
  });
});

/**
 * Format and sanitize conversation messages for Gemini API:
 * 1. Must start with role 'user' (strip initial model/assistant welcome messages).
 * 2. Must alternate strictly between 'user' and 'model'.
 * 3. Filter out empty messages.
 */
function sanitizeConversation(messages: Array<{ role: string; content?: string; image?: any }>) {
  const sanitized: Array<{ role: 'user' | 'model'; parts: any[] }> = [];

  // Filter messages that have content or an image
  const validMessages = messages.filter((m) => {
    const hasText = typeof m.content === 'string' && m.content.trim().length > 0;
    const hasImage = !!m.image?.data;
    return hasText || hasImage;
  });

  // Find first user message
  const firstUserIdx = validMessages.findIndex((m) => m.role === 'user');
  if (firstUserIdx === -1) {
    return [];
  }

  const userStartedList = validMessages.slice(firstUserIdx);

  for (const msg of userStartedList) {
    const role = msg.role === 'user' ? 'user' : 'model';
    const parts: any[] = [];

    if (msg.image?.data) {
      parts.push({
        inlineData: {
          data: msg.image.data,
          mimeType: msg.image.mimeType || 'image/jpeg',
        },
      });
    }

    if (msg.content && msg.content.trim()) {
      parts.push({ text: msg.content.trim() });
    }

    if (parts.length === 0) continue;

    // Strict role alternation: if same role as previous, merge parts
    if (sanitized.length > 0 && sanitized[sanitized.length - 1].role === role) {
      sanitized[sanitized.length - 1].parts.push(...parts);
    } else {
      sanitized.push({ role, parts });
    }
  }

  return sanitized;
}

const BASE_SYSTEM_INSTRUCTION = `You are BIJOY AI ("Your Smart AI Assistant"), an exceptionally smart, modern, friendly, and capable personal AI assistant created for Bijoy.
You are fully fluent in both Bengali (বাংলা) and English.
- If the user writes or speaks in Bengali, respond in natural, polite Bengali.
- If the user writes in English, respond in English.
- If bilingual, adapt gracefully.
Always provide well-structured, formatted responses with Markdown, clear headings, bullet points, and code blocks with language identifiers where appropriate.
Be helpful, concise yet comprehensive, encouraging, and accurate.

AI Vision & Image Understanding Guidelines:
1. When an image is provided, analyze it thoroughly. Identify all visual elements, context, objects, colors, charts, diagrams, or math formulas.
2. OCR & Text Extraction: Extract and transcribe all visible text accurately in English, Bengali (বাংলা), or any other script. Preserve structure and formatting.
3. Multi-Question Image Context: The user may ask multiple follow-up questions about previously uploaded images in the conversation. Seamlessly reference the image from earlier turns to answer accurately.
4. Output Format: All visual analysis and OCR results must be rendered in clean, structured Markdown text only.`;

// Streaming Chat API (SSE)
app.post('/api/chat/stream', async (req: Request, res: Response) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  const {
    messages = [],
    prompt = '',
    image,
    systemInstruction = '',
    language = 'auto',
  } = req.body;

  let langInstruction = '';
  if (language === 'bn') {
    langInstruction = '\nUser preferred language: Respond primarily in Bengali (বাংলা).';
  } else if (language === 'en') {
    langInstruction = '\nUser preferred language: Respond primarily in English.';
  }

  const effectiveInstruction = systemInstruction
    ? `${BASE_SYSTEM_INSTRUCTION}\n\nAdditional Persona: ${systemInstruction}${langInstruction}`
    : `${BASE_SYSTEM_INSTRUCTION}${langInstruction}`;

  try {
    let contents = sanitizeConversation(messages);

    // If no valid sanitized contents, fallback to prompt / image
    if (contents.length === 0) {
      const parts: any[] = [];
      if (image?.data) {
        parts.push({
          inlineData: {
            data: image.data,
            mimeType: image.mimeType || 'image/jpeg',
          },
        });
      }
      parts.push({ text: prompt || 'Hello BIJOY AI' });
      contents = [{ role: 'user', parts }];
    }

    // Try primary fast model with streaming
    let responseStream: any;
    try {
      responseStream = await ai.models.generateContentStream({
        model: PRIMARY_MODEL,
        contents,
        config: {
          systemInstruction: effectiveInstruction,
        },
      });
    } catch (primaryErr: any) {
      console.warn(`Primary model ${PRIMARY_MODEL} error, trying fallback ${FALLBACK_MODEL}:`, primaryErr.message);
      responseStream = await ai.models.generateContentStream({
        model: FALLBACK_MODEL,
        contents,
        config: {
          systemInstruction: effectiveInstruction,
        },
      });
    }

    let emittedAny = false;
    for await (const chunk of responseStream) {
      const chunkText = chunk.text;
      if (chunkText) {
        emittedAny = true;
        res.write(`data: ${JSON.stringify({ chunk: chunkText })}\n\n`);
      }
    }

    if (!emittedAny) {
      res.write(`data: ${JSON.stringify({ chunk: "I'm here to help! What would you like to explore?" })}\n\n`);
    }

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (error: any) {
    console.error('Error in /api/chat/stream:', error);
    res.write(
      `data: ${JSON.stringify({
        error: error.message || 'An error occurred while generating the response.',
        done: true,
      })}\n\n`
    );
    res.end();
  }
});

// Non-streaming Chat API (Direct JSON fallback)
app.post('/api/chat', async (req: Request, res: Response) => {
  const {
    messages = [],
    prompt = '',
    image,
    systemInstruction = '',
    language = 'auto',
  } = req.body;

  let langInstruction = '';
  if (language === 'bn') {
    langInstruction = '\nUser preferred language: Respond in Bengali (বাংলা).';
  } else if (language === 'en') {
    langInstruction = '\nUser preferred language: Respond in English.';
  }

  const effectiveInstruction = systemInstruction
    ? `${BASE_SYSTEM_INSTRUCTION}\n\nAdditional Persona: ${systemInstruction}${langInstruction}`
    : `${BASE_SYSTEM_INSTRUCTION}${langInstruction}`;

  try {
    let contents = sanitizeConversation(messages);
    if (contents.length === 0) {
      const parts: any[] = [];
      if (image?.data) {
        parts.push({
          inlineData: {
            data: image.data,
            mimeType: image.mimeType || 'image/jpeg',
          },
        });
      }
      parts.push({ text: prompt || 'Hello BIJOY AI' });
      contents = [{ role: 'user', parts }];
    }

    let response: any;
    try {
      response = await ai.models.generateContent({
        model: PRIMARY_MODEL,
        contents,
        config: {
          systemInstruction: effectiveInstruction,
        },
      });
    } catch (e: any) {
      console.warn(`Fallback to ${FALLBACK_MODEL}:`, e.message);
      response = await ai.models.generateContent({
        model: FALLBACK_MODEL,
        contents,
        config: {
          systemInstruction: effectiveInstruction,
        },
      });
    }

    res.json({
      success: true,
      text: response.text || "Hello! I am BIJOY AI, ready to help you.",
    });
  } catch (error: any) {
    console.error('Error in /api/chat:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to generate response.',
    });
  }
});

// Dedicated Multimodal Image Understanding & OCR API
app.post('/api/vision/analyze', async (req: Request, res: Response) => {
  try {
    const { image, query, taskType = 'general' } = req.body;

    if (!image?.data) {
      return res.status(400).json({ error: 'Image data is required.' });
    }

    let taskInstruction = `Analyze the uploaded image thoroughly and answer accurately.`;
    if (taskType === 'ocr') {
      taskInstruction = `Extract all visible text from this image precisely. Maintain original formatting, structure, and language (including Bengali or English). If there is handwritten text, decipher it carefully. Explain key points extracted.`;
    } else if (taskType === 'explain') {
      taskInstruction = `Explain everything visible in this image in detail. Identify objects, scene context, colors, relationships, diagrams, charts, or mathematical equations present.`;
    } else if (taskType === 'code_math') {
      taskInstruction = `Inspect this image for any code snippets, UI mockups, or math equations. Transcribe the code or formula precisely into proper markdown code blocks or LaTeX formulas, and provide a comprehensive explanation and solution.`;
    }

    const promptText = query
      ? `${taskInstruction}\n\nUser Question: ${query}`
      : `${taskInstruction}\n\nProvide an insightful summary and key insights.`;

    const response = await ai.models.generateContent({
      model: PRIMARY_MODEL,
      contents: {
        parts: [
          {
            inlineData: {
              data: image.data,
              mimeType: image.mimeType || 'image/jpeg',
            },
          },
          { text: promptText },
        ],
      },
      config: {
        systemInstruction: `You are BIJOY AI Vision Engine. You provide sharp, accurate, structured analysis of images, charts, documents, handwritten notes, and code screenshots. Support Bengali and English naturally.`,
      },
    });

    res.json({
      success: true,
      text: response.text || 'No description generated.',
    });
  } catch (error: any) {
    console.error('Error in /api/vision/analyze:', error);
    res.status(500).json({
      error: error.message || 'Vision analysis failed.',
    });
  }
});

// AI Tools Execution API (8 Specialized tools)
app.post('/api/tools/execute', async (req: Request, res: Response) => {
  try {
    const { toolId, input, options = {} } = req.body;

    if (!input || !input.trim()) {
      return res.status(400).json({ error: 'Input text is required.' });
    }

    const languagePref = options.language || options.lang || 'auto';
    let langInstruction = '';
    if (languagePref === 'bn' || options.targetLang === 'Bengali' || options.targetLang === 'Bengali (বাংলা)') {
      langInstruction = '\nLanguage: Deliver the primary output in natural, fluent, and polite Bengali (বাংলা).';
    } else if (languagePref === 'en') {
      langInstruction = '\nLanguage: Deliver the output in clear, professional English.';
    }

    let systemInstruction = `You are BIJOY AI Specialized Productivity Suite. Produce professional, high quality, ready-to-use output.${langInstruction}`;
    let userPrompt = '';

    switch (toolId) {
      case 'writer': {
        const type = options.type || 'Article';
        const tone = options.tone || 'Professional & Engaging';
        const length = options.length || 'Medium';
        systemInstruction = `You are BIJOY AI Professional Writer. You specialize in crafting high-impact, engaging content with clear structure, compelling headlines, and rich vocabulary.${langInstruction}`;
        userPrompt = `Please write a high quality ${type}.\n\nTopic / Instructions:\n"${input}"\n\nStyle Specifications:\n- Content Type: ${type}\n- Tone: ${tone}\n- Target Length: ${length}\n\nProvide a complete, production-ready draft with an engaging title, well-structured sections with markdown headers, and a strong conclusion.`;
        break;
      }
      case 'translator': {
        const sourceLang = options.sourceLang || 'Auto-Detect';
        const targetLang = options.targetLang || 'Bengali (বাংলা)';
        const formality = options.formality || 'Natural & Professional';
        systemInstruction = `You are BIJOY AI Master Translator. You provide world-class translations preserving cultural context, idioms, grammatical precision, and tone.`;
        userPrompt = `Translate the following text from ${sourceLang} to ${targetLang}.\nFormality/Tone: ${formality}\n\nOriginal Text:\n"""\n${input}\n"""\n\nProvide:\n1. ### Translated Text\n(Accurate, polished translation ready to copy)\n2. ### Pronunciation & Transliteration (if non-Latin or Bengali script)\n3. ### Vocabulary & Idiomatic Breakdown (2-3 key terms explained)`;
        break;
      }
      case 'summarizer': {
        const format = options.format || 'Key Bullet Points';
        const length = options.length || 'Balanced';
        systemInstruction = `You are BIJOY AI Executive Summarizer. You distill dense information, research papers, reports, and articles into sharp, memorable insights without losing core meaning.${langInstruction}`;
        userPrompt = `Summarize the following text.\nFormat: ${format}\nDepth: ${length}\n\nText:\n"""\n${input}\n"""\n\nProvide:\n- Executive TL;DR (1-2 punchy sentences)\n- Core Takeaways (${format})\n- Key Action Items or Conclusions.`;
        break;
      }
      case 'coder': {
        const language = options.language || 'TypeScript / React';
        const task = options.task || 'Write Code from Scratch';
        systemInstruction = `You are BIJOY AI Principal Software Engineer. You write clean, robust, type-safe, bug-free, and scalable code following modern industry best practices.${langInstruction}`;
        userPrompt = `Task: ${task}\nTarget Language / Stack: ${language}\n\nProblem / Specifications:\n"""\n${input}\n"""\n\nProvide:\n1. ### Complete Code Implementation (clean, formatted code block with comments)\n2. ### Technical Explanation & Architecture\n3. ### Complexity & Edge Cases Considered.`;
        break;
      }
      case 'grammar': {
        const level = options.level || 'Grammar + Better Vocabulary';
        systemInstruction = `You are BIJOY AI Grammar & Fluency Editor. You detect grammatical, punctuation, syntax, and stylistic errors in English and Bengali, elevating clarity and impact.`;
        userPrompt = `Review and edit the following text.\nEnhancement Level: ${level}\n\nOriginal Text:\n"""\n${input}\n"""\n\nProvide:\n1. ### Corrected Version\n(Clean, ready-to-copy text)\n2. ### Improvements & Corrections Made\n(Clear bullet points explaining what was fixed)\n3. ### Tone Alternatives\n- Formal / Professional\n- Conversational / Casual`;
        break;
      }
      case 'email': {
        const purpose = options.purpose || 'Client Project Proposal';
        const tone = options.tone || 'Professional & Courteous';
        const recipient = options.recipient || 'Recipient';
        systemInstruction = `You are BIJOY AI Executive Communications Specialist. You write persuasive, elegant, and concise business and personal emails that get results.${langInstruction}`;
        userPrompt = `Draft an email for: ${purpose}\nTone: ${tone}\nRecipient Context: ${recipient}\n\nNotes / Key Points to Include:\n"""\n${input}\n"""\n\nProvide:\n1. ### Subject Line Options (3 catchy options: Standard, Creative, Urgent)\n2. ### Complete Email Body (with greeting, organized paragraphs, call to action, and professional sign-off)\n3. ### Pro Tip / Follow-up Advice.`;
        break;
      }
      case 'study': {
        const mode = options.mode || 'Detailed Concept Explanation';
        const level = options.level || 'College / University';
        systemInstruction = `You are BIJOY AI Elite Academic Tutor. You make difficult scientific, mathematical, historical, and conceptual topics intuitive, engaging, and memorable.${langInstruction}`;
        userPrompt = `Topic / Study Question:\n"""\n${input}\n"""\n\nStudy Mode: ${mode}\nTarget Level: ${level}\n\nProvide:\n1. ### Concept Breakdown (plain language explanation with real-world analogy)\n2. ### Key Definitions & Flashcard Points\n3. ### Common Misconceptions\n4. ### Practice Quiz (3 questions with hidden/explained answers).`;
        break;
      }
      case 'math': {
        const depth = options.depth || 'Detailed Step-by-Step';
        const topic = options.topic || 'General Mathematics';
        systemInstruction = `You are BIJOY AI Senior STEM & Mathematics Specialist. You solve problems with mathematical rigor, clear step-by-step logic, verified formulas, and sanity checks.${langInstruction}`;
        userPrompt = `Math Problem:\n"""\n${input}\n"""\n\nTopic: ${topic}\nSolution Style: ${depth}\n\nProvide:\n1. ### Problem Statement & Given Variables\n2. ### Applicable Formulas & Principles\n3. ### Step-by-Step Derivation & Calculation\n4. ### Final Answer (highlighted in bold box)\n5. ### Sanity Check / Verification Step.`;
        break;
      }
      default:
        userPrompt = input;
    }

    let response: any;
    try {
      response = await ai.models.generateContent({
        model: PRIMARY_MODEL,
        contents: userPrompt,
        config: {
          systemInstruction,
        },
      });
    } catch (primaryErr: any) {
      console.warn(`Tool execution error with ${PRIMARY_MODEL}, trying fallback ${FALLBACK_MODEL}:`, primaryErr.message);
      response = await ai.models.generateContent({
        model: FALLBACK_MODEL,
        contents: userPrompt,
        config: {
          systemInstruction,
        },
      });
    }

    res.json({
      success: true,
      result: response.text || 'No response generated.',
    });
  } catch (error: any) {
    console.error('Error in /api/tools/execute:', error);
    res.status(500).json({
      error: error.message || 'AI Tool execution failed.',
    });
  }
});

// Setup Vite in Dev or Static Serve in Production
async function setupVite() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`BIJOY AI Server running on http://0.0.0.0:${PORT}`);
  });
}

setupVite().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
