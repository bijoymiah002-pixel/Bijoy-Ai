export type ThemeMode = 'dark' | 'light';

export type SupportedLanguage = 'en' | 'bn' | 'auto';

export interface ChatImage {
  data: string; // base64 without prefix or with prefix
  mimeType: string;
  previewUrl: string;
  name?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  image?: ChatImage;
  isStreaming?: boolean;
  error?: boolean;
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: ChatMessage[];
  language?: SupportedLanguage;
}

export type ToolId =
  | 'writer'
  | 'translator'
  | 'summarizer'
  | 'coder'
  | 'grammar'
  | 'email'
  | 'study'
  | 'math';

export interface AIToolConfig {
  id: ToolId;
  name: string;
  bengaliName: string;
  description: string;
  icon: string;
  badge: string;
  gradient: string;
  placeholder: string;
  options: {
    label: string;
    key: string;
    choices: string[];
    default: string;
  }[];
  sampleInputs: string[];
}

export interface UserProfile {
  name: string;
  email: string;
  avatar: string;
  membership: 'Pro Elite' | 'Free';
  preferredLanguage: SupportedLanguage;
  voiceAutoSpeak: boolean;
  speechRate: number;
  speechPitch: number;
  systemPersona: 'balanced' | 'creative' | 'precise' | 'coder';
}
