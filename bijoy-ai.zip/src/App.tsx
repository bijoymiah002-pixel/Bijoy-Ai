import React, { useState } from 'react';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import { ChatProvider, useChat } from './context/ChatContext';
import { Header } from './components/Header';
import { BottomNav, NavTab } from './components/BottomNav';
import { SplashScreen } from './components/SplashScreen';
import { HomeScreen } from './screens/HomeScreen';
import { ChatScreen } from './screens/ChatScreen';
import { VoiceScreen } from './screens/VoiceScreen';
import { ToolsScreen } from './screens/ToolsScreen';
import { HistoryScreen } from './screens/HistoryScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { ChatImage } from './types';
import { MessageSquare, History } from 'lucide-react';

function MainApp() {
  const { theme } = useTheme();
  const { sendMessage, createNewSession, switchSession } = useChat();

  const [hasCompletedSplash, setHasCompletedSplash] = useState(() => {
    // Check if splash has already been shown in this session
    return sessionStorage.getItem('bijoy_splash_shown') === 'true';
  });

  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [chatSubView, setChatSubView] = useState<'conversation' | 'history'>('conversation');

  const handleFinishSplash = () => {
    setHasCompletedSplash(true);
    sessionStorage.setItem('bijoy_splash_shown', 'true');
  };

  const handleReplaySplash = () => {
    setHasCompletedSplash(false);
  };

  const handleStartChat = async (prompt?: string, image?: ChatImage) => {
    setActiveTab('chats');
    setChatSubView('conversation');
    if (prompt || image) {
      await sendMessage(prompt || '', image);
    }
  };

  const handleOpenHistoricalSession = (sessionId: string) => {
    switchSession(sessionId);
    setActiveTab('chats');
    setChatSubView('conversation');
  };

  const handleNewChatFromHeader = () => {
    createNewSession('New Conversation');
    setActiveTab('chats');
    setChatSubView('conversation');
  };

  return (
    <div
      className={`min-h-screen w-full transition-colors duration-300 ${
        theme === 'dark'
          ? 'bg-[#070A12] text-slate-100'
          : 'bg-slate-100 text-slate-900'
      } flex justify-center`}
    >
      {/* Splash Screen */}
      {!hasCompletedSplash && <SplashScreen onFinish={handleFinishSplash} />}

      {/* Main Mobile App Frame */}
      <div className="w-full max-w-md min-h-screen flex flex-col relative shadow-2xl bg-[#0B0F19] dark:bg-[#0B0F19] light:bg-white border-x border-slate-800/40 dark:border-slate-800/60 light:border-slate-200">
        {/* Top Header */}
        <Header onNewChat={handleNewChatFromHeader} />

        {/* Chats Sub-navigation bar when on 'chats' tab */}
        {activeTab === 'chats' && (
          <div className="px-4 py-1.5 bg-slate-900/60 dark:bg-slate-900/60 light:bg-slate-100 border-b border-slate-800 flex items-center justify-center space-x-2">
            <button
              onClick={() => setChatSubView('conversation')}
              className={`flex items-center space-x-1 px-3 py-1 rounded-xl text-xs font-semibold transition-all ${
                chatSubView === 'conversation'
                  ? 'bg-sky-500/20 text-sky-400 border border-sky-500/30 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Current Chat</span>
            </button>
            <button
              onClick={() => setChatSubView('history')}
              className={`flex items-center space-x-1 px-3 py-1 rounded-xl text-xs font-semibold transition-all ${
                chatSubView === 'history'
                  ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>All History</span>
            </button>
          </div>
        )}

        {/* Tab Screens */}
        <main className="flex-1 w-full overflow-x-hidden">
          {activeTab === 'home' && (
            <HomeScreen
              onStartChat={handleStartChat}
              onNavigateTab={(tab) => setActiveTab(tab)}
            />
          )}

          {activeTab === 'chats' && (
            chatSubView === 'conversation' ? (
              <ChatScreen />
            ) : (
              <HistoryScreen onOpenSession={handleOpenHistoricalSession} />
            )
          )}

          {activeTab === 'tools' && (
            <ToolsScreen
              onStartChatWithPrompt={(prompt) => handleStartChat(prompt)}
            />
          )}

          {activeTab === 'voice' && <VoiceScreen />}

          {activeTab === 'profile' && (
            <ProfileScreen onReplaySplash={handleReplaySplash} />
          )}
        </main>

        {/* Persistent Bottom Floating Navigation */}
        <BottomNav
          activeTab={activeTab}
          onTabChange={(tab) => {
            setActiveTab(tab);
            if (tab === 'chats') {
              setChatSubView('conversation');
            }
          }}
        />
      </div>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <ChatProvider>
        <MainApp />
      </ChatProvider>
    </ThemeProvider>
  );
}
