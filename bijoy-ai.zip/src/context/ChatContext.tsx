import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import { ChatImage, ChatMessage, ChatSession, SupportedLanguage, UserProfile } from '../types';

interface ChatContextType {
  sessions: ChatSession[];
  currentSessionId: string;
  currentSession: ChatSession | null;
  isGenerating: boolean;
  isSpeaking: boolean;
  userProfile: UserProfile;
  createNewSession: (title?: string) => string;
  switchSession: (sessionId: string) => void;
  deleteSession: (sessionId: string) => void;
  renameSession: (sessionId: string, newTitle: string) => void;
  clearAllSessions: () => void;
  sendMessage: (text: string, image?: ChatImage) => Promise<void>;
  regenerateLastResponse: () => Promise<void>;
  stopGeneration: () => void;
  speakText: (text: string) => void;
  stopSpeaking: () => void;
  updateUserProfile: (updates: Partial<UserProfile>) => void;
  exportSession: (sessionId: string, format: 'json' | 'txt') => void;
}

const defaultUserProfile: UserProfile = {
  name: 'Bijoy Miah',
  email: 'bijoymiah002@gmail.com',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
  membership: 'Pro Elite',
  preferredLanguage: 'auto',
  voiceAutoSpeak: false,
  speechRate: 1.0,
  speechPitch: 1.0,
  systemPersona: 'balanced',
};

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export const ChatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load sessions from localStorage
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    try {
      const stored = localStorage.getItem('bijoy_ai_sessions');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.error('Error loading sessions from storage:', e);
    }

    const initialSession: ChatSession = {
      id: 'session_' + Date.now(),
      title: 'Welcome to BIJOY AI',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      language: 'auto',
      messages: [
        {
          id: 'msg_welcome',
          role: 'assistant',
          content: `### Welcome to BIJOY AI! 🚀\nI am **BIJOY AI**, your smart personal AI assistant powered by Google Gemini. I am equipped to assist you in **Bengali (বাংলা)** and **English**.\n\nHere is what I can do for you:\n- 💡 **Answer Questions & Solve Problems**\n- 📸 **Image Understanding & OCR Extraction**\n- 🎙️ **Bilingual Voice Conversations**\n- 🛠️ **8 Specialized AI Productivity Tools**\n- 💻 **Write, Debug & Explain Code**\n\nHow can I help you today? Feel free to ask a question or upload an image!`,
          timestamp: Date.now(),
        },
      ],
    };
    return [initialSession];
  });

  const [currentSessionId, setCurrentSessionId] = useState<string>(() => {
    return sessions[0]?.id || 'session_default';
  });

  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    try {
      const stored = localStorage.getItem('bijoy_ai_user_profile');
      if (stored) {
        const parsed = JSON.parse(stored);
        return { ...parsed, voiceAutoSpeak: false };
      }
    } catch (e) {
      console.error(e);
    }
    return { ...defaultUserProfile, voiceAutoSpeak: false };
  });

  const [isGenerating, setIsGenerating] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Sync sessions to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('bijoy_ai_sessions', JSON.stringify(sessions));
    } catch (e) {
      console.error('Failed to save sessions to localStorage:', e);
    }
  }, [sessions]);

  // Sync profile to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('bijoy_ai_user_profile', JSON.stringify(userProfile));
    } catch (e) {
      console.error('Failed to save profile to localStorage:', e);
    }
  }, [userProfile]);

  const currentSession = sessions.find((s) => s.id === currentSessionId) || sessions[0] || null;

  const createNewSession = (title = 'New Conversation') => {
    const newSession: ChatSession = {
      id: 'session_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      title,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      language: userProfile.preferredLanguage,
      messages: [
        {
          id: 'welcome_' + Date.now(),
          role: 'assistant',
          content: `Hello! I'm **BIJOY AI**, ready to assist you. Ask me anything, share code, or upload an image!`,
          timestamp: Date.now(),
        },
      ],
    };

    setSessions((prev) => [newSession, ...prev]);
    setCurrentSessionId(newSession.id);
    return newSession.id;
  };

  const switchSession = (sessionId: string) => {
    if (isGenerating) {
      stopGeneration();
    }
    setCurrentSessionId(sessionId);
  };

  const deleteSession = (sessionId: string) => {
    setSessions((prev) => {
      const filtered = prev.filter((s) => s.id !== sessionId);
      if (filtered.length === 0) {
        const fresh: ChatSession = {
          id: 'session_' + Date.now(),
          title: 'New Conversation',
          createdAt: Date.now(),
          updatedAt: Date.now(),
          messages: [],
        };
        setCurrentSessionId(fresh.id);
        return [fresh];
      }
      if (currentSessionId === sessionId) {
        setCurrentSessionId(filtered[0].id);
      }
      return filtered;
    });
  };

  const renameSession = (sessionId: string, newTitle: string) => {
    setSessions((prev) =>
      prev.map((s) =>
        s.id === sessionId ? { ...s, title: newTitle.trim() || 'Conversation', updatedAt: Date.now() } : s
      )
    );
  };

  const clearAllSessions = () => {
    stopGeneration();
    stopSpeaking();
    const freshSession: ChatSession = {
      id: 'session_' + Date.now(),
      title: 'New Conversation',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: [
        {
          id: 'welcome_' + Date.now(),
          role: 'assistant',
          content: `Conversation history cleared. Ready for your next inquiry!`,
          timestamp: Date.now(),
        },
      ],
    };
    setSessions([freshSession]);
    setCurrentSessionId(freshSession.id);
  };

  const stopGeneration = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsGenerating(false);
  };

  const speakText = (text: string) => {
    if (!('speechSynthesis' in window)) return;

    window.speechSynthesis.cancel();
    // Clean markdown symbols for cleaner voice
    const cleanText = text
      .replace(/```[\s\S]*?```/g, 'Code block omitted.')
      .replace(/[#*`_~>[\]()]/g, '')
      .replace(/\n+/g, ' ')
      .trim();

    if (!cleanText) return;

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = userProfile.speechRate || 1.0;
    utterance.pitch = userProfile.speechPitch || 1.0;

    // Detect language or check characters
    const hasBengali = /[\u0980-\u09FF]/.test(cleanText);
    const voices = window.speechSynthesis.getVoices();

    if (hasBengali) {
      const bnVoice = voices.find((v) => v.lang.includes('bn') || v.lang.includes('BD'));
      if (bnVoice) utterance.voice = bnVoice;
      utterance.lang = 'bn-BD';
    } else {
      const enVoice = voices.find((v) => v.lang.startsWith('en') && (v.name.includes('Natural') || v.name.includes('Google')));
      if (enVoice) utterance.voice = enVoice;
      utterance.lang = 'en-US';
    }

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
  };

  const updateUserProfile = (updates: Partial<UserProfile>) => {
    setUserProfile((prev) => ({ ...prev, ...updates }));
  };

  const exportSession = (sessionId: string, format: 'json' | 'txt') => {
    const session = sessions.find((s) => s.id === sessionId);
    if (!session) return;

    let blob: Blob;
    let filename = `${session.title.replace(/[^a-zA-Z0-9]/g, '_')}_${Date.now()}`;

    if (format === 'json') {
      blob = new Blob([JSON.stringify(session, null, 2)], { type: 'application/json' });
      filename += '.json';
    } else {
      const txtContent = session.messages
        .map((m) => `[${new Date(m.timestamp).toLocaleTimeString()}] ${m.role.toUpperCase()}:\n${m.content}\n`)
        .join('\n----------------------------------------\n\n');
      blob = new Blob([txtContent], { type: 'text/plain;charset=utf-8' });
      filename += '.txt';
    }

    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const sendMessage = async (text: string, image?: ChatImage) => {
    if ((!text.trim() && !image) || isGenerating) return;

    const userMsgId = 'msg_user_' + Date.now();
    const assistantMsgId = 'msg_ai_' + (Date.now() + 1);

    const userMessage: ChatMessage = {
      id: userMsgId,
      role: 'user',
      content: text.trim(),
      timestamp: Date.now(),
      image,
    };

    const initialAssistantMessage: ChatMessage = {
      id: assistantMsgId,
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
      isStreaming: true,
    };

    // Calculate updated title if it's a new or default title session
    const active = sessions.find((s) => s.id === currentSessionId);
    let updatedTitle = active?.title;
    if (active && (active.title === 'New Conversation' || active.messages.length <= 1)) {
      const previewTitle = text.trim().slice(0, 30) || (image ? 'Image Analysis' : 'Chat');
      updatedTitle = previewTitle.length === 30 ? previewTitle + '...' : previewTitle;
    }

    // Append user & temporary assistant message
    setSessions((prev) =>
      prev.map((s) => {
        if (s.id === currentSessionId) {
          return {
            ...s,
            title: updatedTitle || s.title,
            updatedAt: Date.now(),
            messages: [...s.messages, userMessage, initialAssistantMessage],
          };
        }
        return s;
      })
    );

    setIsGenerating(true);
    const abortController = new AbortController();
    abortControllerRef.current = abortController;

    try {
      // Prepare conversation payload - filter completed messages only
      const priorMessages = active
        ? active.messages.filter((m) => m.content && !m.isStreaming)
        : [];
      const conversationHistory = [...priorMessages, userMessage];

      // Formulate persona prompt
      let personaPrompt = '';
      if (userProfile.systemPersona === 'coder') {
        personaPrompt = 'You are in Coding Expert mode. Focus heavily on code elegance, best practices, and runtime efficiency.';
      } else if (userProfile.systemPersona === 'creative') {
        personaPrompt = 'You are in Creative mode. Produce expressive, vivid, and engaging responses.';
      } else if (userProfile.systemPersona === 'precise') {
        personaPrompt = 'You are in Concise & Precise mode. Deliver bullet points and direct answers with minimal fluff.';
      }

      let accumulatedText = '';
      let streamSucceeded = false;

      try {
        const response = await fetch('/api/chat/stream', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          signal: abortController.signal,
          body: JSON.stringify({
            messages: conversationHistory.map((m) => ({
              role: m.role,
              content: m.content,
              image: m.image
                ? {
                    data: m.image.data,
                    mimeType: m.image.mimeType,
                  }
                : undefined,
            })),
            prompt: text.trim(),
            systemInstruction: personaPrompt,
            language: userProfile.preferredLanguage,
          }),
        });

        if (response.ok && response.body) {
          const reader = response.body.getReader();
          const decoder = new TextDecoder('utf-8');
          let buffer = '';

          while (true) {
            const { value, done } = await reader.read();
            if (done) break;

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n\n');
            buffer = lines.pop() || '';

            for (const line of lines) {
              if (line.startsWith('data: ')) {
                const dataStr = line.slice(6).trim();
                if (dataStr) {
                  try {
                    const parsed = JSON.parse(dataStr);
                    if (parsed.chunk) {
                      accumulatedText += parsed.chunk;
                      streamSucceeded = true;
                      setSessions((prev) =>
                        prev.map((s) => {
                          if (s.id === currentSessionId) {
                            return {
                              ...s,
                              messages: s.messages.map((m) =>
                                m.id === assistantMsgId
                                  ? { ...m, content: accumulatedText, isStreaming: true }
                                  : m
                              ),
                            };
                          }
                          return s;
                        })
                      );
                    } else if (parsed.error) {
                      accumulatedText += `\n\n⚠️ ${parsed.error}`;
                    }
                  } catch (err) {
                    console.error('Error parsing SSE line:', err);
                  }
                }
              }
            }
          }
        }
      } catch (streamErr: any) {
        if (streamErr.name === 'AbortError') throw streamErr;
        console.warn('Streaming fetch encountered error, attempting JSON fallback...', streamErr);
      }

      // If streaming didn't produce text, use direct JSON endpoint fallback
      if (!streamSucceeded || !accumulatedText.trim()) {
        const fallbackRes = await fetch('/api/chat', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          signal: abortController.signal,
          body: JSON.stringify({
            messages: conversationHistory.map((m) => ({
              role: m.role,
              content: m.content,
              image: m.image
                ? {
                    data: m.image.data,
                    mimeType: m.image.mimeType,
                  }
                : undefined,
            })),
            prompt: text.trim(),
            systemInstruction: personaPrompt,
            language: userProfile.preferredLanguage,
          }),
        });

        if (fallbackRes.ok) {
          const fallbackData = await fallbackRes.json();
          if (fallbackData.text) {
            accumulatedText = fallbackData.text;
          } else if (fallbackData.error) {
            accumulatedText = `⚠️ ${fallbackData.error}`;
          }
        }
      }

      const finalText = accumulatedText.trim() || "I received your message. How can I assist you further?";

      // Finalize assistant message as text-only by default (no automatic audio playback)
      setSessions((prev) =>
        prev.map((s) => {
          if (s.id === currentSessionId) {
            return {
              ...s,
              messages: s.messages.map((m) =>
                m.id === assistantMsgId
                  ? { ...m, content: finalText, isStreaming: false }
                  : m
              ),
            };
          }
          return s;
        })
      );
    } catch (err: any) {
      if (err.name === 'AbortError') {
        console.log('Generation stopped by user');
      } else {
        console.error('Chat error:', err);
        setSessions((prev) =>
          prev.map((s) => {
            if (s.id === currentSessionId) {
              return {
                ...s,
                messages: s.messages.map((m) =>
                  m.id === assistantMsgId
                    ? {
                        ...m,
                        content: `⚠️ Failed to get AI response: ${err.message || 'Network error'}. Please try asking again.`,
                        isStreaming: false,
                        error: true,
                      }
                    : m
                ),
              };
            }
            return s;
          })
        );
      }
    } finally {
      setIsGenerating(false);
      abortControllerRef.current = null;
      // Guarantee assistant message is never left in isStreaming: true
      setSessions((prev) =>
        prev.map((s) => {
          if (s.id === currentSessionId) {
            return {
              ...s,
              messages: s.messages.map((m) =>
                m.id === assistantMsgId ? { ...m, isStreaming: false } : m
              ),
            };
          }
          return s;
        })
      );
    }
  };

  const regenerateLastResponse = async () => {
    if (!currentSession || isGenerating) return;
    const msgs = currentSession.messages;
    if (msgs.length === 0) return;

    // Find last user message
    let lastUserIndex = -1;
    for (let i = msgs.length - 1; i >= 0; i--) {
      if (msgs[i].role === 'user') {
        lastUserIndex = i;
        break;
      }
    }

    if (lastUserIndex === -1) return;

    const userMessage = msgs[lastUserIndex];
    // Remove subsequent messages after this user message
    setSessions((prev) =>
      prev.map((s) => {
        if (s.id === currentSessionId) {
          return {
            ...s,
            messages: s.messages.slice(0, lastUserIndex),
          };
        }
        return s;
      })
    );

    await sendMessage(userMessage.content, userMessage.image);
  };

  return (
    <ChatContext.Provider
      value={{
        sessions,
        currentSessionId,
        currentSession,
        isGenerating,
        isSpeaking,
        userProfile,
        createNewSession,
        switchSession,
        deleteSession,
        renameSession,
        clearAllSessions,
        sendMessage,
        regenerateLastResponse,
        stopGeneration,
        speakText,
        stopSpeaking,
        updateUserProfile,
        exportSession,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = () => {
  const ctx = useContext(ChatContext);
  if (!ctx) throw new Error('useChat must be used within ChatProvider');
  return ctx;
};
