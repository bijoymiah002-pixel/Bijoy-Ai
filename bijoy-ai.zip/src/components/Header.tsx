import React from 'react';
import { BijoyLogo } from './BijoyLogo';
import { useTheme } from '../context/ThemeContext';
import { useChat } from '../context/ChatContext';
import { Sun, Moon, Plus, Sparkles, Globe } from 'lucide-react';

interface HeaderProps {
  onNewChat?: () => void;
  title?: string;
}

export const Header: React.FC<HeaderProps> = ({ onNewChat, title }) => {
  const { theme, toggleTheme } = useTheme();
  const { createNewSession, userProfile, updateUserProfile } = useChat();

  const handleCreateNew = () => {
    if (onNewChat) {
      onNewChat();
    } else {
      createNewSession('New Conversation');
    }
  };

  const toggleLanguage = () => {
    const nextLang = userProfile.preferredLanguage === 'bn' ? 'en' : 'bn';
    updateUserProfile({ preferredLanguage: nextLang });
  };

  return (
    <header className="sticky top-0 z-30 w-full backdrop-blur-xl bg-[#070A12]/80 dark:bg-[#070A12]/85 light:bg-white/85 border-b border-slate-800/80 dark:border-slate-850 light:border-slate-200/90 transition-colors">
      <div className="max-w-md mx-auto px-4 py-2.5 flex items-center justify-between">
        {/* Left: Logo & Title */}
        <div className="flex items-center space-x-2.5">
          <BijoyLogo size={34} animated={true} />
          <div>
            <div className="flex items-center space-x-1.5">
              <span className="font-extrabold text-base tracking-tight bg-gradient-to-r from-sky-400 via-indigo-300 to-purple-400 bg-clip-text text-transparent">
                {title || 'BIJOY AI'}
              </span>
              <span className="flex items-center px-1.5 py-0.5 rounded-full text-[9px] font-bold bg-sky-500/15 text-sky-400 border border-sky-500/30">
                <Sparkles className="w-2.5 h-2.5 mr-0.5 text-cyan-400" /> PRO
              </span>
            </div>
            <div className="text-[10px] text-slate-400 dark:text-slate-400 light:text-slate-500 font-medium">
              Your Smart AI Assistant
            </div>
          </div>
        </div>

        {/* Right Action Buttons */}
        <div className="flex items-center space-x-1.5">
          {/* Bengali/English Quick Switcher */}
          <button
            onClick={toggleLanguage}
            title="Toggle Language"
            className="flex items-center space-x-1 px-2 py-1 rounded-xl bg-slate-800/60 dark:bg-slate-800/60 light:bg-slate-100 border border-slate-700/60 dark:border-slate-700/60 light:border-slate-200 text-[11px] font-semibold text-slate-300 dark:text-slate-300 light:text-slate-700 hover:border-sky-500/50 transition-all active:scale-95"
          >
            <Globe className="w-3 h-3 text-sky-400" />
            <span>{userProfile.preferredLanguage === 'bn' ? 'বাংলা' : 'EN'}</span>
          </button>

          {/* Theme Toggle Button */}
          <button
            onClick={toggleTheme}
            title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            className="p-1.5 rounded-xl bg-slate-800/60 dark:bg-slate-800/60 light:bg-slate-100 border border-slate-700/60 dark:border-slate-700/60 light:border-slate-200 text-slate-300 dark:text-slate-300 light:text-slate-700 hover:text-sky-400 transition-all active:scale-95"
          >
            {theme === 'dark' ? (
              <Sun className="w-4 h-4 text-amber-400" />
            ) : (
              <Moon className="w-4 h-4 text-indigo-600" />
            )}
          </button>

          {/* New Chat Button */}
          <button
            onClick={handleCreateNew}
            title="Start New Chat"
            className="flex items-center space-x-1 px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white font-medium text-xs shadow-[0_0_12px_rgba(56,189,248,0.4)] transition-all active:scale-95"
          >
            <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
            <span className="hidden sm:inline">New</span>
          </button>
        </div>
      </div>
    </header>
  );
};
