import React, { useEffect, useState } from 'react';
import { BijoyLogo } from './BijoyLogo';
import { Sparkles, ArrowRight } from 'lucide-react';

interface SplashScreenProps {
  onFinish: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  const [progress, setProgress] = useState(10);
  const [fade, setFade] = useState(false);

  useEffect(() => {
    const timer1 = setTimeout(() => setProgress(45), 400);
    const timer2 = setTimeout(() => setProgress(80), 1000);
    const timer3 = setTimeout(() => setProgress(100), 1600);
    const timer4 = setTimeout(() => {
      setFade(true);
      setTimeout(onFinish, 400);
    }, 2100);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      clearTimeout(timer4);
    };
  }, [onFinish]);

  const handleSkip = () => {
    setFade(true);
    setTimeout(onFinish, 200);
  };

  return (
    <div
      onClick={handleSkip}
      className={`fixed inset-0 z-50 flex flex-col items-center justify-between p-6 select-none cursor-pointer transition-opacity duration-400 ${
        fade ? 'opacity-0 pointer-events-none' : 'opacity-100'
      } bg-[#070A12] text-white overflow-hidden`}
      style={{
        backgroundImage: `
          radial-gradient(circle at 50% 30%, rgba(99, 102, 241, 0.25) 0%, transparent 60%),
          radial-gradient(circle at 80% 80%, rgba(56, 189, 248, 0.18) 0%, transparent 50%),
          radial-gradient(circle at 20% 90%, rgba(168, 85, 247, 0.2) 0%, transparent 50%)
        `,
      }}
    >
      {/* Background cyber ambient rings */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[340px] h-[340px] rounded-full border border-indigo-500/15 animate-ping pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[480px] h-[480px] rounded-full border border-sky-500/10 pointer-events-none" />

      {/* Top micro badge */}
      <div className="pt-8 flex items-center space-x-2 text-xs font-semibold tracking-wider text-sky-400/80 uppercase">
        <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-spin" style={{ animationDuration: '6s' }} />
        <span>Next-Gen Intelligence</span>
      </div>

      {/* Center Logo & Tagline */}
      <div className="flex flex-col items-center text-center px-4">
        <div className="mb-6 relative">
          <BijoyLogo size={105} animated={true} withGlow={true} />
        </div>

        <h1 className="text-4xl font-extrabold tracking-tight mb-2">
          <span className="bg-gradient-to-r from-sky-400 via-indigo-300 to-purple-400 bg-clip-text text-transparent">
            BIJOY AI
          </span>
        </h1>

        <p className="text-base font-medium text-slate-300 tracking-wide max-w-xs">
          Your Smart AI Assistant
        </p>

        <p className="text-xs text-slate-400 mt-2 font-mono">
          বাংলা & English • Vision • Voice • Tools
        </p>

        {/* Progress Bar & Status */}
        <div className="w-56 mt-8">
          <div className="h-1.5 w-full bg-slate-800/80 rounded-full overflow-hidden p-0.5 border border-indigo-500/20">
            <div
              className="h-full bg-gradient-to-r from-sky-400 via-indigo-500 to-fuchsia-500 rounded-full transition-all duration-500 ease-out shadow-[0_0_12px_rgba(56,189,248,0.8)]"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2 font-mono">
            <span>Neural Engine</span>
            <span>{progress}%</span>
          </div>
        </div>
      </div>

      {/* Bottom quick CTA */}
      <div className="pb-8 w-full max-w-xs flex flex-col items-center">
        <button
          onClick={handleSkip}
          className="w-full py-3 px-5 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-center space-x-2 text-sm font-semibold text-slate-200 backdrop-blur-md transition-all active:scale-95"
        >
          <span>Tap to Continue</span>
          <ArrowRight className="w-4 h-4 text-sky-400" />
        </button>
        <span className="text-[10px] text-slate-400 mt-3">
          Powered by Gemini 3.8 Flash • v2.5 Mobile
        </span>
      </div>
    </div>
  );
};
