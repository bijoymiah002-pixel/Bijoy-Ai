import React from 'react';

interface BijoyLogoProps {
  size?: number;
  className?: string;
  withGlow?: boolean;
  animated?: boolean;
}

export const BijoyLogo: React.FC<BijoyLogoProps> = ({
  size = 40,
  className = '',
  withGlow = true,
  animated = false,
}) => {
  const gradientId = `bijoy_logo_grad_${Math.random().toString(36).substring(2, 7)}`;
  const glowId = `bijoy_glow_${Math.random().toString(36).substring(2, 7)}`;

  return (
    <div
      className={`relative inline-flex items-center justify-center ${className}`}
      style={{ width: size, height: size }}
    >
      {withGlow && (
        <div
          className={`absolute inset-0 rounded-2xl bg-gradient-to-tr from-cyan-500 via-indigo-600 to-fuchsia-500 blur-lg opacity-60 ${
            animated ? 'animate-pulse-glow' : ''
          }`}
          style={{ transform: 'scale(0.85)' }}
        />
      )}
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`relative z-10 transition-transform duration-300 ${
          animated ? 'hover:scale-105' : ''
        }`}
      >
        <defs>
          <linearGradient id={gradientId} x1="10" y1="10" x2="90" y2="90" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#38BDF8" />     {/* Electric Blue */}
            <stop offset="50%" stopColor="#818CF8" />    {/* Indigo */}
            <stop offset="100%" stopColor="#C084FC" />   {/* Neon Purple */}
          </linearGradient>

          <linearGradient id={`${gradientId}_dark`} x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#0B0F19" />
            <stop offset="100%" stopColor="#1E1B4B" />
          </linearGradient>

          <filter id={glowId} x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Outer Rounded Squircle Glass Tile */}
        <rect
          x="6"
          y="6"
          width="88"
          height="88"
          rx="24"
          fill={`url(#${gradientId}_dark)`}
          stroke={`url(#${gradientId})`}
          strokeWidth="3.5"
          className="shadow-2xl"
        />

        {/* Ambient Neural Grid Dots */}
        <circle cx="26" cy="26" r="2.5" fill="#38BDF8" opacity="0.6" />
        <circle cx="74" cy="26" r="2.5" fill="#C084FC" opacity="0.6" />
        <circle cx="26" cy="74" r="2.5" fill="#818CF8" opacity="0.6" />
        <circle cx="74" cy="74" r="2.5" fill="#38BDF8" opacity="0.6" />

        {/* Futuristic Stylized 'B' + Neural Node Network */}
        {/* Left vertical neural stem */}
        <path
          d="M32 24 C32 20 36 20 40 20 L40 80 C36 80 32 80 32 76 Z"
          fill={`url(#${gradientId})`}
          filter={`url(#${glowId})`}
        />

        {/* Upper lobe of B with dynamic cyber cut */}
        <path
          d="M38 22 H54 C66 22 72 28 72 37 C72 45 65 50 54 50 H38 Z"
          stroke={`url(#${gradientId})`}
          strokeWidth="6"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Lower lobe of B with power loop */}
        <path
          d="M38 50 H57 C70 50 76 56 76 66 C76 75 68 78 55 78 H38 Z"
          stroke={`url(#${gradientId})`}
          strokeWidth="6"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Central Neural Synapse Core (Pulsing Diamond) */}
        <polygon
          points="50,44 56,50 50,56 44,50"
          fill="#38BDF8"
          className="animate-pulse"
        />

        {/* Circuit accent lines */}
        <line x1="56" y1="50" x2="68" y2="50" stroke="#38BDF8" strokeWidth="2.5" strokeLinecap="round" opacity="0.8" />
        <circle cx="68" cy="50" r="3" fill="#C084FC" />
      </svg>
    </div>
  );
};
