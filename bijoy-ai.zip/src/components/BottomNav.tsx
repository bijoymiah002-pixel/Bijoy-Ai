import React from 'react';
import { Home, MessageSquare, Wrench, Mic, User } from 'lucide-react';

export type NavTab = 'home' | 'chats' | 'tools' | 'voice' | 'profile';

interface BottomNavProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  unreadCount?: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onTabChange,
  unreadCount = 0,
}) => {
  const tabs = [
    { id: 'home' as NavTab, label: 'Home', icon: Home },
    { id: 'chats' as NavTab, label: 'Chats', icon: MessageSquare, badge: unreadCount },
    { id: 'tools' as NavTab, label: 'AI Tools', icon: Wrench },
    { id: 'voice' as NavTab, label: 'Voice', icon: Mic, isVoice: true },
    { id: 'profile' as NavTab, label: 'Profile', icon: User },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 px-3 pb-3 pt-1 pointer-events-auto">
      <div className="max-w-md mx-auto backdrop-blur-xl bg-[#0B0F19]/90 dark:bg-[#0B0F19]/95 light:bg-white/90 border border-slate-700/50 dark:border-slate-800 light:border-slate-200/80 rounded-3xl shadow-[0_10px_35px_-5px_rgba(0,0,0,0.5)] px-2 py-1.5 flex items-center justify-around">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          if (tab.isVoice) {
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className="relative -top-3 flex flex-col items-center focus:outline-none group"
                aria-label="Voice Assistant"
              >
                <div
                  className={`w-13 h-13 rounded-2xl flex items-center justify-center shadow-lg transition-all duration-300 transform ${
                    isActive
                      ? 'bg-gradient-to-tr from-cyan-400 via-indigo-600 to-purple-600 text-white scale-110 shadow-[0_0_20px_rgba(56,189,248,0.7)]'
                      : 'bg-gradient-to-tr from-sky-500 via-indigo-500 to-purple-500 text-white hover:scale-105 shadow-[0_0_15px_rgba(99,102,241,0.5)]'
                  }`}
                >
                  <Icon className="w-6 h-6 animate-pulse" />
                </div>
                <span
                  className={`text-[10px] font-semibold mt-0.5 tracking-tight ${
                    isActive ? 'text-sky-400 font-bold' : 'text-slate-400 group-hover:text-slate-200'
                  }`}
                >
                  Voice
                </span>
              </button>
            );
          }

          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className="relative py-1.5 px-3 flex flex-col items-center justify-center rounded-2xl transition-all duration-200 group focus:outline-none"
            >
              {isActive && (
                <div className="absolute inset-0 bg-gradient-to-r from-sky-500/15 via-indigo-500/15 to-purple-500/15 rounded-2xl border border-sky-500/30 -z-0" />
              )}
              <div className="relative">
                <Icon
                  className={`w-5 h-5 transition-transform duration-200 ${
                    isActive
                      ? 'text-sky-400 scale-110'
                      : 'text-slate-400 dark:text-slate-400 light:text-slate-500 group-hover:text-slate-200'
                  }`}
                />
                {tab.badge && tab.badge > 0 ? (
                  <span className="absolute -top-1 -right-2 bg-rose-500 text-white text-[9px] font-bold px-1.5 py-0.2 rounded-full min-w-4 text-center">
                    {tab.badge}
                  </span>
                ) : null}
              </div>
              <span
                className={`text-[10.5px] mt-1 font-medium transition-colors ${
                  isActive
                    ? 'text-sky-400 dark:text-sky-400 light:text-indigo-600 font-semibold'
                    : 'text-slate-400 dark:text-slate-400 light:text-slate-500 group-hover:text-slate-200'
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
