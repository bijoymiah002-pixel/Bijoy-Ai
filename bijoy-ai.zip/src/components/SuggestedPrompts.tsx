import React from 'react';
import { PenTool, Brain, Code, Languages, Sparkles } from 'lucide-react';

interface SuggestedPromptsProps {
  onSelectPrompt: (promptText: string) => void;
}

export const SuggestedPrompts: React.FC<SuggestedPromptsProps> = ({ onSelectPrompt }) => {
  const prompts = [
    {
      title: 'Write something for me',
      bengaliTitle: 'আমার জন্য কিছু লিখুন',
      desc: 'Craft an essay, blog post, or creative story',
      prompt: 'Write an inspiring, engaging article about the future of Artificial Intelligence in our daily lives.',
      icon: PenTool,
      color: 'from-amber-500/20 to-orange-500/20 text-amber-400 border-amber-500/30',
    },
    {
      title: 'Explain a difficult topic',
      bengaliTitle: 'কঠিন বিষয় বুঝিয়ে বলুন',
      desc: 'Simplify quantum computing or photosynthesis',
      prompt: 'Explain Quantum Computing like I am 12 years old, with real-world analogies and everyday examples.',
      icon: Brain,
      color: 'from-indigo-500/20 to-purple-500/20 text-indigo-400 border-indigo-500/30',
    },
    {
      title: 'Help me with coding',
      bengaliTitle: 'কোডিং এ সাহায্য করুন',
      desc: 'Debug code, build algorithms, or create apps',
      prompt: 'Write a modern TypeScript React hook for debounced search with automatic cancellation and error handling.',
      icon: Code,
      color: 'from-sky-500/20 to-cyan-500/20 text-sky-400 border-sky-500/30',
    },
    {
      title: 'Translate any language',
      bengaliTitle: 'যেকোনো ভাষায় অনুবাদ করুন',
      desc: 'Accurate Bengali & English translation',
      prompt: 'Translate the following English business email to polite, professional Bengali (বাংলা): "Dear Bijoy, Thank you for sending over the project proposal. We were thoroughly impressed with your technical architecture."',
      icon: Languages,
      color: 'from-emerald-500/20 to-teal-500/20 text-emerald-400 border-emerald-500/30',
    },
  ];

  return (
    <div className="w-full my-4">
      <div className="flex items-center space-x-2 mb-3 px-1">
        <Sparkles className="w-3.5 h-3.5 text-sky-400" />
        <span className="text-xs font-semibold text-slate-400 dark:text-slate-400 light:text-slate-600 uppercase tracking-wider">
          Suggested Prompts
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {prompts.map((item, idx) => {
          const Icon = item.icon;
          return (
            <button
              key={idx}
              onClick={() => onSelectPrompt(item.prompt)}
              className="text-left p-3.5 rounded-2xl bg-slate-900/60 dark:bg-slate-900/60 light:bg-slate-50 hover:bg-slate-800/80 dark:hover:bg-slate-800/80 light:hover:bg-slate-100 border border-slate-800 dark:border-slate-800 light:border-slate-200 hover:border-sky-500/40 transition-all duration-200 group active:scale-[0.98] shadow-sm"
            >
              <div className="flex items-start space-x-3">
                <div
                  className={`p-2 rounded-xl bg-gradient-to-br ${item.color} border shrink-0`}
                >
                  <Icon className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-xs text-slate-100 dark:text-slate-100 light:text-slate-800 group-hover:text-sky-300 transition-colors">
                    {item.title}
                  </div>
                  <div className="text-[11px] text-slate-400 dark:text-slate-400 light:text-slate-500 mt-0.5 line-clamp-1">
                    {item.desc}
                  </div>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
