import React, { useState } from 'react';
import { Copy, Check, Terminal } from 'lucide-react';

interface MarkdownRendererProps {
  content: string;
  className?: string;
}

export const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({
  content,
  className = '',
}) => {
  const [copiedCodeIndex, setCopiedCodeIndex] = useState<number | null>(null);

  const handleCopyCode = (codeText: string, index: number) => {
    navigator.clipboard.writeText(codeText);
    setCopiedCodeIndex(index);
    setTimeout(() => {
      setCopiedCodeIndex(null);
    }, 2000);
  };

  // Parse markdown blocks (code blocks ```code``` vs inline markdown)
  const renderBlocks = () => {
    if (!content) return null;

    // Split on code fences ```lang ... ```
    const regex = /```([a-zA-Z0-9_\-+]*)\n([\s\S]*?)```/g;
    const parts: React.ReactNode[] = [];
    let lastIndex = 0;
    let match: RegExpExecArray | null;
    let blockCounter = 0;

    while ((match = regex.exec(content)) !== null) {
      // Text before code block
      if (match.index > lastIndex) {
        const textChunk = content.substring(lastIndex, match.index);
        parts.push(
          <div key={`text-${lastIndex}`} className="space-y-2">
            {renderFormattedText(textChunk)}
          </div>
        );
      }

      const language = match[1] || 'text';
      const code = match[2].trim();
      const codeIndex = blockCounter++;

      parts.push(
        <div
          key={`code-${codeIndex}`}
          className="my-3 rounded-xl overflow-hidden border border-slate-700/60 bg-[#0B0F19] shadow-lg text-xs"
        >
          {/* Header */}
          <div className="flex items-center justify-between px-3.5 py-1.5 bg-slate-900/90 border-b border-slate-800 text-slate-400">
            <div className="flex items-center space-x-1.5 font-mono text-[11px] text-sky-400 font-medium">
              <Terminal className="w-3.5 h-3.5" />
              <span>{language || 'code'}</span>
            </div>
            <button
              onClick={() => handleCopyCode(code, codeIndex)}
              className="flex items-center space-x-1 px-2 py-0.5 rounded-md hover:bg-slate-800 text-slate-300 hover:text-white transition-colors"
            >
              {copiedCodeIndex === codeIndex ? (
                <>
                  <Check className="w-3 h-3 text-emerald-400" />
                  <span className="text-[10px] text-emerald-400">Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" />
                  <span className="text-[10px]">Copy code</span>
                </>
              )}
            </button>
          </div>
          {/* Code block */}
          <pre className="p-3.5 overflow-x-auto font-mono text-[11px] leading-relaxed text-indigo-100 bg-[#070A12]/90">
            <code>{code}</code>
          </pre>
        </div>
      );

      lastIndex = regex.lastIndex;
    }

    // Remaining text after last code block
    if (lastIndex < content.length) {
      parts.push(
        <div key={`text-${lastIndex}`} className="space-y-2">
          {renderFormattedText(content.substring(lastIndex))}
        </div>
      );
    }

    return parts;
  };

  const renderFormattedText = (rawText: string) => {
    const lines = rawText.split('\n');

    return lines.map((line, idx) => {
      // Empty line
      if (!line.trim()) {
        return <div key={idx} className="h-1.5" />;
      }

      // Headings
      if (line.startsWith('### ')) {
        return (
          <h4 key={idx} className="font-bold text-sm text-sky-300 mt-2 mb-1">
            {formatInline(line.replace('### ', ''))}
          </h4>
        );
      }
      if (line.startsWith('## ')) {
        return (
          <h3 key={idx} className="font-extrabold text-base text-indigo-300 mt-2.5 mb-1.5">
            {formatInline(line.replace('## ', ''))}
          </h3>
        );
      }
      if (line.startsWith('# ')) {
        return (
          <h2 key={idx} className="font-extrabold text-lg text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-purple-400 mt-3 mb-1.5">
            {formatInline(line.replace('# ', ''))}
          </h2>
        );
      }

      // Bullet points
      if (line.trim().startsWith('- ') || line.trim().startsWith('* ')) {
        const bulletContent = line.trim().substring(2);
        return (
          <div key={idx} className="flex items-start space-x-2 my-0.5 pl-1">
            <span className="text-sky-400 text-sm leading-none mt-1.5">•</span>
            <div className="flex-1 text-inherit">
              {formatInline(bulletContent)}
            </div>
          </div>
        );
      }

      // Numbered points (e.g., 1. or 2.)
      const numMatch = line.trim().match(/^(\d+)\.\s+(.*)$/);
      if (numMatch) {
        return (
          <div key={idx} className="flex items-start space-x-2 my-0.5 pl-1">
            <span className="font-mono text-xs font-bold text-purple-400 mt-0.5 min-w-[1.2rem]">
              {numMatch[1]}.
            </span>
            <div className="flex-1 text-inherit">
              {formatInline(numMatch[2])}
            </div>
          </div>
        );
      }

      // Blockquotes
      if (line.startsWith('> ')) {
        return (
          <blockquote
            key={idx}
            className="border-l-2 border-indigo-500 pl-3 py-1 my-1 italic text-slate-300/90 bg-indigo-500/10 rounded-r-lg"
          >
            {formatInline(line.replace('> ', ''))}
          </blockquote>
        );
      }

      // Standard paragraph line
      return (
        <p key={idx} className="leading-relaxed">
          {formatInline(line)}
        </p>
      );
    });
  };

  // Inline formatting for **bold**, *italic*, and `code`
  const formatInline = (str: string) => {
    // Replace inline code `code`
    const parts = str.split(/(`[^`]+`|\*\*[^*]+\*\*|\*[^*]+\*)/g);

    return parts.map((part, i) => {
      if (part.startsWith('`') && part.endsWith('`')) {
        return (
          <code
            key={i}
            className="px-1.5 py-0.5 mx-0.5 text-[11px] font-mono rounded bg-slate-800/80 text-sky-300 border border-slate-700/60"
          >
            {part.slice(1, -1)}
          </code>
        );
      }
      if (part.startsWith('**') && part.endsWith('**')) {
        return (
          <strong key={i} className="font-bold text-sky-200">
            {part.slice(2, -2)}
          </strong>
        );
      }
      if (part.startsWith('*') && part.endsWith('*')) {
        return (
          <em key={i} className="italic text-slate-200">
            {part.slice(1, -1)}
          </em>
        );
      }
      return part;
    });
  };

  return <div className={`text-sm leading-relaxed ${className}`}>{renderBlocks()}</div>;
};
