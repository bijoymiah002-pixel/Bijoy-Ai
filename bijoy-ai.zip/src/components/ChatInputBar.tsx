import React, { useRef, useState, useEffect } from 'react';
import { Send, Image as ImageIcon, Mic, MicOff, Square, X, Paperclip, Sparkles, FileText, ZoomIn } from 'lucide-react';
import { ChatImage } from '../types';

interface ChatInputBarProps {
  onSend: (text: string, image?: ChatImage) => void;
  isGenerating: boolean;
  onStop: () => void;
  placeholder?: string;
  initialText?: string;
  activeSessionImage?: ChatImage | null;
}

export const ChatInputBar: React.FC<ChatInputBarProps> = ({
  onSend,
  isGenerating,
  onStop,
  placeholder = 'Ask BIJOY AI or inquire about an image...',
  initialText = '',
  activeSessionImage = null,
}) => {
  const [inputText, setInputText] = useState(initialText);
  const [selectedImage, setSelectedImage] = useState<ChatImage | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [isProcessingImage, setIsProcessingImage] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    if (initialText) {
      setInputText(initialText);
      if (textareaRef.current) {
        textareaRef.current.focus();
      }
    }
  }, [initialText]);

  // Speech recognition initialization
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          transcript += event.results[i][0].transcript;
        }
        if (transcript) {
          setInputText((prev) => (prev ? `${prev} ${transcript}` : transcript));
        }
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    }
  }, []);

  const toggleMic = () => {
    if (!recognitionRef.current) {
      alert('Speech recognition is not supported in this browser.');
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      try {
        recognitionRef.current.start();
        setIsListening(true);
      } catch (e) {
        console.error(e);
      }
    }
  };

  /**
   * Process and compress image client-side to ensure optimal Gemini vision resolution
   * without exhausting browser localStorage or network bandwidth.
   */
  const processImageFile = (file: File) => {
    setIsProcessingImage(true);
    const validMimes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    const mime = validMimes.includes(file.type.toLowerCase()) ? file.type : 'image/jpeg';

    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new window.Image();
      img.onload = () => {
        const maxDim = 1600;
        let width = img.width;
        let height = img.height;

        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL(mime, 0.9);
          const base64Data = dataUrl.split(',')[1];

          setSelectedImage({
            data: base64Data,
            mimeType: mime,
            previewUrl: dataUrl,
            name: file.name,
          });
        }
        setIsProcessingImage(false);
      };

      img.onerror = () => {
        setIsProcessingImage(false);
      };

      img.src = e.target?.result as string;
    };

    reader.onerror = () => {
      setIsProcessingImage(false);
    };

    reader.readAsDataURL(file);
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processImageFile(file);
    e.target.value = '';
  };

  const handleSubmit = (textToSend?: string) => {
    if (isGenerating) {
      onStop();
      return;
    }

    const content = typeof textToSend === 'string' ? textToSend : inputText;

    // If an image is selected without explicit text, provide an intelligent default vision prompt
    let effectiveText = content.trim();
    if (!effectiveText && selectedImage) {
      effectiveText = 'Please analyze this image thoroughly. Identify key objects, text, charts, or context and explain what you see in detail.';
    }

    if (!effectiveText && !selectedImage) return;

    onSend(effectiveText, selectedImage || undefined);
    setInputText('');
    setSelectedImage(null);

    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInputText(e.target.value);
    e.target.style.height = 'auto';
    e.target.style.height = `${Math.min(e.target.scrollHeight, 120)}px`;
  };

  return (
    <div className="w-full">
      {/* Hidden file input supporting JPG, JPEG, PNG, and WEBP */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/jpeg,image/jpg,image/png,image/webp"
        onChange={handleImageSelect}
        className="hidden"
      />

      {/* Selected Image Thumbnail preview with remove button */}
      {selectedImage && (
        <div className="mb-2 p-2.5 rounded-2xl bg-slate-900/95 dark:bg-slate-900/95 light:bg-slate-100 border border-sky-500/40 flex flex-col space-y-2 animate-fade-in shadow-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3 overflow-hidden">
              <div className="relative group/thumb shrink-0">
                <img
                  src={selectedImage.previewUrl}
                  alt="Upload preview"
                  className="w-14 h-14 rounded-xl object-cover border border-sky-500/50 shadow-md"
                />
                <span className="absolute bottom-0 right-0 p-0.5 rounded-full bg-slate-950/80 text-sky-400">
                  <ZoomIn className="w-3 h-3" />
                </span>
              </div>
              <div className="text-left overflow-hidden">
                <div className="text-xs font-bold text-sky-300 truncate max-w-[210px]">
                  {selectedImage.name || 'Uploaded Image'}
                </div>
                <div className="text-[11px] text-emerald-400 flex items-center font-medium mt-0.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1 animate-pulse" />
                  Ready for Gemini Vision & OCR
                </div>
              </div>
            </div>

            <button
              onClick={() => setSelectedImage(null)}
              title="Remove image"
              className="p-1.5 rounded-full bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 border border-slate-700 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Quick Vision Prompts Chips */}
          <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 text-[11px] scrollbar-none">
            <button
              type="button"
              onClick={() => handleSubmit('Extract and read all text from this image precisely (OCR). Keep formatting and explain.')}
              className="px-2.5 py-1 rounded-xl bg-sky-500/15 hover:bg-sky-500/25 text-sky-300 border border-sky-500/30 whitespace-nowrap font-medium flex items-center space-x-1 transition-colors"
            >
              <FileText className="w-3 h-3 text-cyan-400" />
              <span>Read Text (OCR)</span>
            </button>
            <button
              type="button"
              onClick={() => handleSubmit('Analyze this image in detail and describe everything you see.')}
              className="px-2.5 py-1 rounded-xl bg-purple-500/15 hover:bg-purple-500/25 text-purple-300 border border-purple-500/30 whitespace-nowrap font-medium transition-colors"
            >
              🔍 Describe Image
            </button>
            <button
              type="button"
              onClick={() => handleSubmit('এই ছবিতে কী কী আছে এবং কী লেখা আছে বিস্তারিত বাংলায় বুঝিয়ে বলুন।')}
              className="px-2.5 py-1 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 whitespace-nowrap font-medium transition-colors"
            >
              🇧🇩 বাংলায় বুঝান
            </button>
          </div>
        </div>
      )}

      {/* Notice if an image is already active in the ongoing multi-turn conversation */}
      {!selectedImage && activeSessionImage && (
        <div className="mb-2 px-3 py-1.5 rounded-xl bg-indigo-950/40 border border-indigo-500/30 flex items-center justify-between text-[11px] text-indigo-300">
          <div className="flex items-center space-x-2">
            <img
              src={activeSessionImage.previewUrl}
              alt="Active image"
              className="w-5 h-5 rounded-md object-cover border border-indigo-400"
            />
            <span>Active image in chat • You can ask follow-up questions about it</span>
          </div>
        </div>
      )}

      {/* Image processing loader */}
      {isProcessingImage && (
        <div className="mb-2 px-3 py-1.5 rounded-xl bg-sky-500/10 border border-sky-500/30 flex items-center space-x-2 text-xs text-sky-300">
          <span className="w-3 h-3 rounded-full border-2 border-sky-400 border-t-transparent animate-spin" />
          <span>Processing and optimizing image for Gemini Vision...</span>
        </div>
      )}

      {/* Listening status indicator */}
      {isListening && (
        <div className="mb-2 px-3 py-1.5 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center justify-between text-xs text-red-400">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
            <span className="font-medium">Listening to your voice... Speak now</span>
          </div>
          <button
            onClick={toggleMic}
            className="text-[11px] font-bold text-red-300 hover:underline"
          >
            Stop
          </button>
        </div>
      )}

      {/* Message Input Container */}
      <div className="relative rounded-2xl bg-[#0F172A]/90 dark:bg-[#0F172A]/90 light:bg-white border border-slate-700/60 dark:border-slate-800 light:border-slate-300 p-2 shadow-lg focus-within:border-sky-500/60 focus-within:shadow-[0_0_20px_rgba(56,189,248,0.2)] transition-all">
        <textarea
          ref={textareaRef}
          value={inputText}
          onChange={handleTextChange}
          onKeyDown={handleKeyDown}
          placeholder={
            selectedImage
              ? 'Ask anything about this image (English or বাংলা)...'
              : placeholder
          }
          rows={1}
          className="w-full bg-transparent resize-none text-sm text-slate-100 dark:text-slate-100 light:text-slate-900 placeholder:text-slate-400/80 px-2.5 py-1.5 outline-none max-h-32 min-h-[40px] leading-relaxed"
        />

        {/* Action icons bar */}
        <div className="flex items-center justify-between pt-1 px-1 border-t border-slate-800/40 dark:border-slate-800/50 light:border-slate-100">
          {/* Left Media Actions */}
          <div className="flex items-center space-x-1">
            {/* Image upload button */}
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              title="Upload Image (JPG, JPEG, PNG, WEBP) for AI Vision & OCR"
              className={`p-2 rounded-xl transition-all ${
                selectedImage
                  ? 'bg-sky-500/20 text-sky-400 border border-sky-500/40'
                  : 'text-slate-400 hover:text-sky-400 hover:bg-slate-800/50 dark:hover:bg-slate-800/50 light:hover:bg-slate-100'
              }`}
            >
              <ImageIcon className="w-4 h-4" />
            </button>

            {/* Document attachment / OCR shortcut */}
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              title="Attach document photo or screenshot"
              className="p-2 rounded-xl text-slate-400 hover:text-indigo-400 hover:bg-slate-800/50 dark:hover:bg-slate-800/50 light:hover:bg-slate-100 transition-colors"
            >
              <Paperclip className="w-4 h-4" />
            </button>

            {/* Microphone button */}
            <button
              type="button"
              onClick={toggleMic}
              title="Voice Input"
              className={`p-2 rounded-xl transition-all ${
                isListening
                  ? 'bg-rose-500 text-white animate-pulse'
                  : 'text-slate-400 hover:text-sky-400 hover:bg-slate-800/50 dark:hover:bg-slate-800/50 light:hover:bg-slate-100'
              }`}
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>
          </div>

          {/* Right: Send or Stop Button */}
          <div className="flex items-center space-x-2">
            {isGenerating ? (
              <button
                type="button"
                onClick={onStop}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-rose-500 hover:bg-rose-600 text-white text-xs font-semibold shadow-md active:scale-95 transition-all"
              >
                <Square className="w-3.5 h-3.5 fill-current" />
                <span>Stop</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => handleSubmit()}
                disabled={!inputText.trim() && !selectedImage}
                className={`p-2 rounded-xl flex items-center justify-center transition-all ${
                  inputText.trim() || selectedImage
                    ? 'bg-gradient-to-r from-sky-500 via-indigo-600 to-purple-600 text-white shadow-[0_0_15px_rgba(99,102,241,0.5)] active:scale-95'
                    : 'bg-slate-800 dark:bg-slate-800 light:bg-slate-200 text-slate-500 dark:text-slate-500 light:text-slate-400 cursor-not-allowed'
                }`}
              >
                <Send className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
