import React, { useState } from 'react';
import { useChat } from '../context/ChatContext';
import {
  Search,
  MessageSquare,
  Trash2,
  Edit2,
  Check,
  X,
  Download,
  Plus,
  ArrowRight,
  Clock,
  Sparkles,
} from 'lucide-react';

export const HistoryScreen: React.FC<{
  onOpenSession: (sessionId: string) => void;
}> = ({ onOpenSession }) => {
  const {
    sessions,
    currentSessionId,
    deleteSession,
    renameSession,
    clearAllSessions,
    createNewSession,
    exportSession,
  } = useChat();

  const [searchQuery, setSearchQuery] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  const filteredSessions = sessions.filter((s) => {
    const matchesTitle = s.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesMessage = s.messages.some((m) =>
      m.content.toLowerCase().includes(searchQuery.toLowerCase())
    );
    return matchesTitle || matchesMessage;
  });

  const startEditing = (sessionId: string, currentTitle: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(sessionId);
    setEditTitle(currentTitle);
  };

  const saveEditing = (sessionId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (editTitle.trim()) {
      renameSession(sessionId, editTitle.trim());
    }
    setEditingId(null);
  };

  const cancelEditing = (e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(null);
  };

  const handleDelete = (sessionId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    deleteSession(sessionId);
  };

  const handleExport = (sessionId: string, format: 'json' | 'txt', e: React.MouseEvent) => {
    e.stopPropagation();
    exportSession(sessionId, format);
  };

  return (
    <div className="flex flex-col min-h-[calc(100vh-130px)] pb-24 px-4 max-w-md mx-auto text-left">
      {/* Header */}
      <div className="pt-2 pb-3 flex items-center justify-between">
        <div>
          <h2 className="text-xl font-black tracking-tight text-slate-100">
            Chat History
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {sessions.length} saved conversation{sessions.length === 1 ? '' : 's'}
          </p>
        </div>

        <button
          onClick={() => {
            const newId = createNewSession();
            onOpenSession(newId);
          }}
          className="flex items-center space-x-1 px-3 py-1.5 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 text-white text-xs font-semibold shadow-md active:scale-95"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Chat</span>
        </button>
      </div>

      {/* Search Input Box */}
      <div className="relative my-2">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search conversations by keywords..."
          className="w-full pl-9 pr-4 py-2.5 rounded-2xl bg-slate-900/80 dark:bg-slate-900/80 light:bg-slate-50 border border-slate-800 dark:border-slate-800 light:border-slate-200 text-xs text-slate-100 placeholder:text-slate-500 outline-none focus:border-sky-500 transition-colors"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Sessions List */}
      <div className="flex-1 space-y-2 mt-2 overflow-y-auto">
        {filteredSessions.length > 0 ? (
          filteredSessions.map((session) => {
            const isActive = session.id === currentSessionId;
            const messageCount = session.messages.length;
            const lastMessage =
              session.messages[session.messages.length - 1]?.content || 'Empty chat';
            const dateStr = new Date(session.updatedAt).toLocaleDateString(undefined, {
              month: 'short',
              day: 'numeric',
            });

            return (
              <div
                key={session.id}
                onClick={() => onOpenSession(session.id)}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer group active:scale-[0.99] relative ${
                  isActive
                    ? 'bg-slate-800/90 border-sky-500/50 shadow-md'
                    : 'bg-slate-900/60 dark:bg-slate-900/60 light:bg-slate-50 border-slate-800/80 dark:border-slate-800/80 light:border-slate-200 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between">
                  {/* Left Title / Rename */}
                  <div className="flex-1 min-w-0 pr-2">
                    {editingId === session.id ? (
                      <div
                        onClick={(e) => e.stopPropagation()}
                        className="flex items-center space-x-1.5"
                      >
                        <input
                          type="text"
                          value={editTitle}
                          onChange={(e) => setEditTitle(e.target.value)}
                          className="bg-slate-800 text-slate-100 text-xs px-2 py-1 rounded-lg border border-sky-500 outline-none flex-1"
                          autoFocus
                        />
                        <button
                          onClick={(e) => saveEditing(session.id, e)}
                          className="p-1 text-emerald-400 hover:bg-slate-700 rounded-lg"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={cancelEditing}
                          className="p-1 text-slate-400 hover:bg-slate-700 rounded-lg"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center space-x-2">
                        <MessageSquare
                          className={`w-4 h-4 shrink-0 ${
                            isActive ? 'text-sky-400' : 'text-slate-400'
                          }`}
                        />
                        <h4 className="font-semibold text-xs text-slate-200 truncate group-hover:text-sky-300 transition-colors">
                          {session.title}
                        </h4>
                      </div>
                    )}

                    <p className="text-[11px] text-slate-400 truncate mt-1 pl-6">
                      {lastMessage.replace(/[#*`]/g, '')}
                    </p>
                  </div>

                  {/* Actions (Rename, Export, Delete) */}
                  <div className="flex items-center space-x-1 shrink-0 opacity-80 group-hover:opacity-100">
                    <button
                      onClick={(e) => startEditing(session.id, session.title, e)}
                      title="Rename"
                      className="p-1 rounded-lg hover:bg-slate-700/60 text-slate-400 hover:text-slate-200"
                    >
                      <Edit2 className="w-3 h-3" />
                    </button>
                    <button
                      onClick={(e) => handleExport(session.id, 'txt', e)}
                      title="Download as Text"
                      className="p-1 rounded-lg hover:bg-slate-700/60 text-slate-400 hover:text-sky-400"
                    >
                      <Download className="w-3 h-3" />
                    </button>
                    <button
                      onClick={(e) => handleDelete(session.id, e)}
                      title="Delete chat"
                      className="p-1 rounded-lg hover:bg-slate-700/60 text-slate-400 hover:text-rose-400"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>

                {/* Footer metadata */}
                <div className="flex items-center justify-between text-[10px] text-slate-500 mt-2 pl-6">
                  <span>{messageCount} messages</span>
                  <span>{dateStr}</span>
                </div>
              </div>
            );
          })
        ) : (
          <div className="text-center py-12 text-slate-500">
            <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-40" />
            <p className="text-xs">No conversations found</p>
          </div>
        )}
      </div>

      {/* Clear All Sessions Option */}
      {sessions.length > 0 && (
        <div className="mt-4 pt-3 border-t border-slate-800/80">
          {showClearConfirm ? (
            <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-between">
              <span className="text-xs text-rose-300 font-semibold">
                Delete all chat history?
              </span>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setShowClearConfirm(false)}
                  className="px-2.5 py-1 text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    clearAllSessions();
                    setShowClearConfirm(false);
                  }}
                  className="px-3 py-1 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold"
                >
                  Confirm Delete
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => setShowClearConfirm(true)}
              className="w-full py-2 text-center text-xs text-slate-400 hover:text-rose-400 flex items-center justify-center space-x-1.5 transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear Entire Conversation History</span>
            </button>
          )}
        </div>
      )}
    </div>
  );
};
