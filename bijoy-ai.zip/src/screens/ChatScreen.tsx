import React, { useRef, useEffect, useState } from 'react';
import { useChat } from '../context/ChatContext';
import { MarkdownRenderer } from '../components/MarkdownRenderer';
import { ChatInputBar } from '../components/ChatInputBar';
import { ChatImage } from '../types';
import {
  Copy,
  Check,
  Share2,
  RotateCcw,
  Volume2,
  VolumeX,
  Sparkles,
  User,
  Square,
  Bot,
  ExternalLink,
  ZoomIn,
  X,
  Eye,
} from 'lucide-react';
import { BijoyLogo } from '../components/BijoyLogo';

export const ChatScreen: React.FC = () => {
  const {
    currentSession,
    isGenerating,
    sendMessage,
    stopGeneration,
    regenerateLastResponse,
    speakText,
    stopSpeaking,
    isSpeaking,
    userProfile,
  } = useChat();

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);
  const [previewModalImage, setPreviewModalImage] = useState<string | null>(null);

  // Identify most recent image in active session for multi-turn questions
  const activeSessionImage =
    currentSession?.messages
      .slice()
      .reverse()
      .find((m) => m.image)?.image || null;

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [currentSession?.messages, isGenerating]);

  useEffect(() => {
    if (!isSpeaking) {
      setSpeakingMsgId(null);
    }
  }, [isSpeaking]);

  useEffect(() => {
    return () => {
      stopSpeaking();
    };
  }, []);

  const handleCopyMessage = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleShareMessage = async (text: string) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'BIJOY AI Response',
          text: text,
        });
      } catch (err) {
        console.log('Share canceled or failed', err);
      }
    } else {
      handleCopyMessage(text, 'share');
    }
  };

  const handleToggleSpeak = (text: string, id: string) => {
    if (isSpeaking && speakingMsgId === id) {
      stopSpeaking();
      setSpeakingMsgId(null);
    } else {
      stopSpeaking();
      speakText(text);
      setSpeakingMsgId(id);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-125px)] max-w-md mx-auto relative">
      {/* Session Title Bar */}
      <div className="px-4 py-2 border-b border-slate-800/60 dark:border-slate-800/60 light:border-slate-200 flex items-center justify-between text-xs text-slate-400">
        <div className="flex items-center space-x-2 truncate">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
          <span className="font-semibold text-slate-200 dark:text-slate-200 light:text-slate-700 truncate max-w-[240px]">
            {currentSession?.title || 'Active Conversation'}
          </span>
        </div>
        <div className="flex items-center space-x-1.5 shrink-0 text-[11px] font-mono text-sky-400">
          <span>{currentSession?.messages.length || 0} msgs</span>
        </div>
      </div>

      {/* Message List */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {currentSession?.messages.map((message, index) => {
          const isUser = message.role === 'user';
          const isLastAssistant =
            !isUser && index === (currentSession.messages.length - 1);

          return (
            <div
              key={message.id || index}
              className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} group animate-fade-in`}
            >
              <div className="flex items-start space-x-2 max-w-[92%]">
                {/* Assistant Avatar */}
                {!isUser && (
                  <div className="mt-1 shrink-0">
                    <BijoyLogo size={28} withGlow={false} />
                  </div>
                )}

                {/* Message Bubble */}
                <div
                  className={`rounded-2xl px-4 py-3 shadow-md ${
                    isUser
                      ? 'bg-gradient-to-r from-sky-600 via-indigo-600 to-purple-600 text-white rounded-tr-none'
                      : 'bg-slate-900/90 dark:bg-slate-900/90 light:bg-white text-slate-100 dark:text-slate-100 light:text-slate-900 border border-slate-800 dark:border-slate-800 light:border-slate-200/90 rounded-tl-none'
                  }`}
                >
                  {/* Attached Image if present */}
                  {message.image && (
                    <div className="mb-2.5 rounded-xl overflow-hidden border border-white/20 max-w-[260px] relative group/img cursor-pointer shadow-md">
                      <img
                        src={message.image.previewUrl}
                        alt="User uploaded attachment"
                        className="w-full max-h-56 object-cover transition-transform group-hover/img:scale-102"
                        onClick={() => setPreviewModalImage(message.image?.previewUrl || null)}
                      />
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setPreviewModalImage(message.image?.previewUrl || null);
                        }}
                        className="absolute bottom-2 right-2 p-1.5 rounded-lg bg-black/75 hover:bg-black/90 text-white backdrop-blur-sm transition-all"
                        title="View Full Image"
                      >
                        <ZoomIn className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}

                  {/* Text / Markdown Content */}
                  {message.content ? (
                    isUser ? (
                      <p className="text-sm whitespace-pre-wrap leading-relaxed">
                        {message.content}
                      </p>
                    ) : (
                      <MarkdownRenderer content={message.content} />
                    )
                  ) : message.isStreaming ? (
                    <div className="flex items-center space-x-2 py-1 text-sky-400 text-xs">
                      <span className="w-2 h-2 rounded-full bg-sky-400 animate-ping" />
                      <span className="font-mono">BIJOY AI is thinking...</span>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-1.5 py-1 text-slate-400 text-xs">
                      <span>No response received.</span>
                    </div>
                  )}

                  {/* Streaming indicator inside bubble */}
                  {message.isStreaming && message.content && (
                    <span className="inline-block w-2 h-4 ml-1 bg-sky-400 animate-pulse align-middle" />
                  )}
                </div>

                {/* User Avatar */}
                {isUser && (
                  <div className="mt-1 shrink-0 w-7 h-7 rounded-full bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center text-white text-xs font-bold shadow-md">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>

              {/* Action Toolbar for Assistant Messages */}
              {!isUser && message.content && !message.isStreaming && (
                <div className="flex items-center space-x-1 ml-9 mt-1.5 text-slate-400 dark:text-slate-400 light:text-slate-500">
                  {/* Copy Button */}
                  <button
                    onClick={() => handleCopyMessage(message.content, message.id)}
                    title="Copy message"
                    className="p-1 rounded-lg hover:bg-slate-800/60 dark:hover:bg-slate-800/60 light:hover:bg-slate-100 hover:text-slate-200 transition-colors"
                  >
                    {copiedId === message.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>

                  {/* Speaker Icon (🔊) - Tap to play or stop voice */}
                  <button
                    onClick={() => handleToggleSpeak(message.content, message.id)}
                    title={isSpeaking && speakingMsgId === message.id ? 'Stop audio' : 'Listen to response'}
                    className={`flex items-center space-x-1 px-1.5 py-1 rounded-lg text-xs font-medium transition-all ${
                      isSpeaking && speakingMsgId === message.id
                        ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 shadow-sm animate-pulse'
                        : 'hover:bg-slate-800/60 dark:hover:bg-slate-800/60 light:hover:bg-slate-100 hover:text-sky-300'
                    }`}
                  >
                    {isSpeaking && speakingMsgId === message.id ? (
                      <>
                        <VolumeX className="w-3.5 h-3.5 text-rose-400" />
                        <span className="text-[10px] text-sky-300 font-semibold">Stop</span>
                      </>
                    ) : (
                      <>
                        <Volume2 className="w-3.5 h-3.5 text-sky-400" />
                        <span className="text-[10px] text-slate-400 group-hover/btn:text-slate-200">Listen</span>
                      </>
                    )}
                  </button>

                  {/* Share Button */}
                  <button
                    onClick={() => handleShareMessage(message.content)}
                    title="Share response"
                    className="p-1 rounded-lg hover:bg-slate-800/60 hover:text-slate-200 transition-colors"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                  </button>

                  {/* Regenerate button (on the latest assistant reply) */}
                  {isLastAssistant && (
                    <button
                      onClick={regenerateLastResponse}
                      disabled={isGenerating}
                      title="Regenerate response"
                      className="flex items-center space-x-1 p-1 px-1.5 rounded-lg hover:bg-slate-800/60 hover:text-sky-300 text-[11px] font-medium transition-colors"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Retry</span>
                    </button>
                  )}
                </div>
              )}
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Floating Stop Generation Pill */}
      {isGenerating && (
        <div className="absolute bottom-20 left-1/2 -translate-x-1/2 z-20">
          <button
            onClick={stopGeneration}
            className="flex items-center space-x-2 px-4 py-2 rounded-full bg-slate-900 text-rose-400 border border-rose-500/40 shadow-xl backdrop-blur-md hover:bg-slate-800 active:scale-95 transition-all"
          >
            <Square className="w-3.5 h-3.5 fill-current" />
            <span className="text-xs font-bold">Stop Generation</span>
          </button>
        </div>
      )}

      {/* Bottom Input Area */}
      <div className="p-3 border-t border-slate-800/80 dark:border-slate-800/80 light:border-slate-200 bg-[#070A12]/95 dark:bg-[#070A12]/95 light:bg-white/95">
        <ChatInputBar
          onSend={sendMessage}
          isGenerating={isGenerating}
          onStop={stopGeneration}
          activeSessionImage={activeSessionImage}
          placeholder="Message BIJOY AI in বাংলা or English..."
        />
      </div>

      {/* Image Lightbox Modal */}
      {previewModalImage && (
        <div
          onClick={() => setPreviewModalImage(null)}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4 animate-fade-in"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-lg w-full max-h-[90vh] flex flex-col items-center justify-center"
          >
            <button
              onClick={() => setPreviewModalImage(null)}
              className="absolute -top-10 right-0 p-2 rounded-full bg-slate-800/80 text-white hover:bg-slate-700 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={previewModalImage}
              alt="Full view"
              className="max-w-full max-h-[80vh] object-contain rounded-2xl border border-slate-700 shadow-2xl"
            />
          </div>
        </div>
      )}
    </div>
  );
};
