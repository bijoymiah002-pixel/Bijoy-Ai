import React, { useState, useEffect, useRef } from 'react';
import { useChat } from '../context/ChatContext';
import { BijoyLogo } from '../components/BijoyLogo';
import { Mic, MicOff, Volume2, VolumeX, Sparkles, Languages, Check, ArrowRight, RefreshCw } from 'lucide-react';

export const VoiceScreen: React.FC = () => {
  const { speakText, stopSpeaking, isSpeaking, userProfile, updateUserProfile } = useChat();

  const [voiceLang, setVoiceLang] = useState<'bn-BD' | 'en-US'>('en-US');
  const [voiceStatus, setVoiceStatus] = useState<'idle' | 'listening' | 'thinking' | 'speaking'>('idle');
  const [transcript, setTranscript] = useState('');
  const [aiVoiceResponse, setAiVoiceResponse] = useState('');
  const recognitionRef = useRef<any>(null);

  // Sync with global language preference initially
  useEffect(() => {
    if (userProfile.preferredLanguage === 'bn') {
      setVoiceLang('bn-BD');
    } else {
      setVoiceLang('en-US');
    }
  }, [userProfile.preferredLanguage]);

  // Setup Web Speech API SpeechRecognition
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = voiceLang;

      recognition.onstart = () => {
        setVoiceStatus('listening');
      };

      recognition.onresult = (event: any) => {
        let current = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          current += event.results[i][0].transcript;
        }
        setTranscript(current);
      };

      recognition.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setVoiceStatus('idle');
      };

      recognition.onend = () => {
        // When speech recognition ends, if we have transcript, query AI!
        if (transcript.trim()) {
          processVoiceQuery(transcript);
        } else {
          setVoiceStatus('idle');
        }
      };

      recognitionRef.current = recognition;
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
    };
  }, [voiceLang, transcript]);

  // Handle speech synthesis state sync
  useEffect(() => {
    if (isSpeaking) {
      setVoiceStatus('speaking');
    } else if (voiceStatus === 'speaking') {
      setVoiceStatus('idle');
    }
  }, [isSpeaking]);

  const toggleListening = () => {
    if (isSpeaking) {
      stopSpeaking();
    }

    if (voiceStatus === 'listening') {
      recognitionRef.current?.stop();
      setVoiceStatus('idle');
    } else {
      setTranscript('');
      setAiVoiceResponse('');
      try {
        if (recognitionRef.current) {
          recognitionRef.current.lang = voiceLang;
          recognitionRef.current.start();
        } else {
          alert('Speech Recognition is not available in this browser. Please use Google Chrome or Edge.');
        }
      } catch (err) {
        console.error('Failed to start recognition:', err);
      }
    }
  };

  const processVoiceQuery = async (queryText: string) => {
    setVoiceStatus('thinking');

    try {
      const systemInstruction = `You are BIJOY AI Voice Companion.
Provide a concise, conversational, spoken answer (maximum 2-3 natural sentences) that sounds great when spoken aloud.
Language target: ${voiceLang === 'bn-BD' ? 'Bengali (বাংলা)' : 'English'}.
Do not output markdown tables or code syntax; use natural spoken language.`;

      const res = await fetch('/api/tools/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          toolId: 'writer',
          input: queryText,
          options: {
            type: 'Voice Response',
            tone: 'Conversational & Friendly',
            length: 'Brief Spoken Answer',
          },
        }),
      });

      const data = await res.json();
      const reply = data.result || 'I heard you, but could not produce a response.';
      setAiVoiceResponse(reply);
      setVoiceStatus('speaking');
      speakText(reply);
    } catch (err) {
      console.error('Voice query error:', err);
      setAiVoiceResponse('Sorry, I encountered an issue processing that. Please try again.');
      setVoiceStatus('idle');
    }
  };

  const handleLangToggle = (lang: 'bn-BD' | 'en-US') => {
    setVoiceLang(lang);
    if (recognitionRef.current) {
      recognitionRef.current.lang = lang;
    }
    updateUserProfile({ preferredLanguage: lang === 'bn-BD' ? 'bn' : 'en' });
  };

  return (
    <div className="flex flex-col h-[calc(100vh-130px)] justify-between max-w-md mx-auto px-5 py-4 text-center select-none">
      {/* Top Controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <BijoyLogo size={32} animated={voiceStatus !== 'idle'} />
          <span className="font-extrabold text-sm tracking-wide bg-gradient-to-r from-sky-400 to-indigo-300 bg-clip-text text-transparent">
            VOICE ASSISTANT
          </span>
        </div>

        {/* Language Pill Selector */}
        <div className="flex items-center bg-slate-800/80 rounded-2xl p-1 border border-slate-700/60 shadow-inner">
          <button
            onClick={() => handleLangToggle('en-US')}
            className={`px-3 py-1 rounded-xl text-xs font-semibold transition-all ${
              voiceLang === 'en-US'
                ? 'bg-gradient-to-r from-sky-500 to-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            English
          </button>
          <button
            onClick={() => handleLangToggle('bn-BD')}
            className={`px-3 py-1 rounded-xl text-xs font-semibold transition-all ${
              voiceLang === 'bn-BD'
                ? 'bg-gradient-to-r from-sky-500 to-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            বাংলা
          </button>
        </div>
      </div>

      {/* Main Interactive Animated Mic Center */}
      <div className="flex flex-col items-center justify-center my-auto py-6">
        {/* Pulsating Glowing Sound Wave Rings */}
        <div className="relative flex items-center justify-center">
          {voiceStatus !== 'idle' && (
            <>
              <div className="absolute w-64 h-64 rounded-full border border-sky-500/25 animate-ping pointer-events-none" />
              <div
                className="absolute w-52 h-52 rounded-full border border-indigo-500/30 animate-pulse pointer-events-none"
                style={{ animationDuration: '1.8s' }}
              />
              <div className="absolute w-40 h-40 rounded-full bg-gradient-to-tr from-sky-500/20 via-indigo-600/20 to-purple-500/20 blur-xl pointer-events-none" />
            </>
          )}

          {/* Central Button Orb */}
          <button
            onClick={toggleListening}
            className={`relative z-10 w-28 h-28 rounded-full flex flex-col items-center justify-center transition-all duration-300 transform active:scale-95 shadow-2xl ${
              voiceStatus === 'listening'
                ? 'bg-gradient-to-tr from-rose-500 via-pink-600 to-red-500 text-white scale-110 shadow-[0_0_35px_rgba(244,63,94,0.7)]'
                : voiceStatus === 'thinking'
                ? 'bg-gradient-to-tr from-amber-500 via-indigo-600 to-purple-600 text-white animate-spin shadow-[0_0_30px_rgba(245,158,11,0.6)]'
                : voiceStatus === 'speaking'
                ? 'bg-gradient-to-tr from-cyan-400 via-indigo-600 to-purple-600 text-white shadow-[0_0_35px_rgba(56,189,248,0.8)]'
                : 'bg-gradient-to-tr from-sky-500 via-indigo-600 to-purple-700 text-white hover:scale-105 shadow-[0_0_25px_rgba(99,102,241,0.5)]'
            }`}
          >
            {voiceStatus === 'listening' ? (
              <Mic className="w-10 h-10 animate-bounce" />
            ) : voiceStatus === 'thinking' ? (
              <RefreshCw className="w-10 h-10 animate-spin" />
            ) : voiceStatus === 'speaking' ? (
              <Volume2 className="w-10 h-10 animate-pulse" />
            ) : (
              <Mic className="w-10 h-10" />
            )}
          </button>
        </div>

        {/* Animated Audio Equalizer Bars */}
        <div className="flex items-center justify-center space-x-1.5 h-12 mt-8">
          {[40, 75, 55, 90, 60, 85, 45, 95, 50, 70].map((height, i) => (
            <div
              key={i}
              className={`w-1 rounded-full transition-all duration-200 ${
                voiceStatus === 'listening' || voiceStatus === 'speaking'
                  ? 'bg-gradient-to-t from-sky-400 to-fuchsia-400 animate-pulse'
                  : 'bg-slate-700 h-2'
              }`}
              style={{
                height:
                  voiceStatus === 'listening' || voiceStatus === 'speaking'
                    ? `${(height * (0.6 + Math.random() * 0.5)).toFixed(0)}%`
                    : '6px',
                animationDelay: `${i * 0.1}s`,
              }}
            />
          ))}
        </div>

        {/* Status Text */}
        <div className="mt-4">
          <div className="text-base font-bold text-slate-100">
            {voiceStatus === 'listening'
              ? 'Listening to you...'
              : voiceStatus === 'thinking'
              ? 'BIJOY AI is thinking...'
              : voiceStatus === 'speaking'
              ? 'Speaking response...'
              : 'Tap microphone to speak'}
          </div>
          <div className="text-xs text-slate-400 mt-1 font-mono">
            {voiceLang === 'bn-BD' ? 'বাংলায় কথা বলুন (Bengali)' : 'Speak in English'}
          </div>
        </div>
      </div>

      {/* Transcript & Response Display Card */}
      <div className="w-full rounded-2xl bg-slate-900/80 dark:bg-slate-900/80 light:bg-slate-50 border border-slate-800 dark:border-slate-800 light:border-slate-200 p-4 text-left shadow-lg mb-2 min-h-[110px] flex flex-col justify-between">
        {transcript || aiVoiceResponse ? (
          <div className="space-y-2">
            {transcript && (
              <div className="text-xs">
                <span className="font-semibold text-sky-400">You: </span>
                <span className="text-slate-200">{transcript}</span>
              </div>
            )}
            {aiVoiceResponse && (
              <div className="text-xs pt-1.5 border-t border-slate-800">
                <span className="font-semibold text-purple-400">BIJOY AI: </span>
                <span className="text-slate-100 leading-relaxed">{aiVoiceResponse}</span>
              </div>
            )}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center py-2 text-slate-500">
            <Sparkles className="w-5 h-5 mb-1.5 text-slate-600" />
            <p className="text-xs">
              Say e.g.: "What is the capital of Bangladesh?" or "আমাকে আজকের আবহাওয়া বলুন"
            </p>
          </div>
        )}

        {isSpeaking && (
          <div className="flex justify-end mt-2">
            <button
              onClick={stopSpeaking}
              className="text-[10px] font-bold text-rose-400 hover:underline flex items-center space-x-1"
            >
              <VolumeX className="w-3 h-3" />
              <span>Mute Voice</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
