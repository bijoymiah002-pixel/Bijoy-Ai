import React from 'react';
import { useChat } from '../context/ChatContext';
import { SuggestedPrompts } from '../components/SuggestedPrompts';
import { ChatInputBar } from '../components/ChatInputBar';
import { ChatImage } from '../types';
import { Sparkles, Zap, Image, Mic, MessageSquare, ArrowRight, ShieldCheck } from 'lucide-react';
import { BijoyLogo } from '../components/BijoyLogo';

interface HomeScreenProps {
  onStartChat: (initialPrompt?: string, image?: ChatImage) => void;
  onNavigateTab: (tab: any) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({ onStartChat, onNavigateTab }) => {
  const { isGenerating, stopGeneration, userProfile } = useChat();

  const handleSend = (text: string, image?: ChatImage) => {
    onStartChat(text, image);
  };

  return (
    <div className="flex flex-col min-h-[calc(100vh-140px)] justify-between pb-24 px-4 max-w-md mx-auto">
      {/* Top Welcome Section */}
      <div className="pt-4 flex flex-col items-center text-center">
        {/* Animated Avatar / Logo badge */}
        <div className="relative mb-3">
          <BijoyLogo size={68} animated={true} withGlow={true} />
          <span className="absolute -bottom-1 -right-1 flex h-4 w-4">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-4 w-4 bg-emerald-500 border-2 border-[#0B0F19]"></span>
          </span>
        </div>

        {/* Dynamic Welcome Heading */}
        <h1 className="text-2xl font-black tracking-tight text-slate-100 dark:text-slate-100 light:text-slate-900">
          Hello, {userProfile.name.split(' ')[0]}! 👋
        </h1>
        <p className="text-base font-semibold bg-gradient-to-r from-sky-400 via-indigo-300 to-purple-400 bg-clip-text text-transparent mt-0.5">
          How can I help you today?
        </p>
        <p className="text-xs text-slate-400 dark:text-slate-400 light:text-slate-500 mt-1 max-w-xs">
          আজকে আমি আপনাকে কীভাবে সহায়তা করতে পারি? Ask in English or বাংলা!
        </p>

        {/* AI Assistant Introduction Glass Card */}
        <div className="w-full mt-4 p-4 rounded-3xl bg-gradient-to-br from-indigo-950/40 via-slate-900/60 to-[#0B0F19] dark:from-indigo-950/40 dark:via-slate-900/60 dark:to-[#0B0F19] light:from-indigo-50 light:to-white border border-indigo-500/20 dark:border-indigo-500/20 light:border-indigo-100 shadow-xl backdrop-blur-md text-left relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-sky-500/10 rounded-full blur-2xl pointer-events-none" />

          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <span className="p-1.5 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-500/30">
                <Zap className="w-3.5 h-3.5" />
              </span>
              <span className="text-xs font-bold uppercase tracking-wider text-sky-300 dark:text-sky-300 light:text-indigo-700">
                BIJOY AI Core v2.5
              </span>
            </div>
            <span className="text-[10px] font-mono font-medium px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Gemini 3.8 Flash
            </span>
          </div>

          <p className="text-xs text-slate-300 dark:text-slate-300 light:text-slate-600 leading-relaxed">
            Your high-speed personal intelligence for research, content drafting, vision OCR, bilingual voice discussions, and instant coding solutions.
          </p>

          {/* Feature shortcuts row */}
          <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-slate-800/80 dark:border-slate-800/80 light:border-slate-200">
            <button
              onClick={() => onNavigateTab('voice')}
              className="flex items-center space-x-1.5 p-1.5 rounded-xl bg-slate-800/40 dark:bg-slate-800/40 light:bg-slate-100 hover:bg-slate-800 text-[11px] font-medium text-slate-300 dark:text-slate-300 light:text-slate-700 transition-colors"
            >
              <Mic className="w-3.5 h-3.5 text-cyan-400" />
              <span>Voice</span>
            </button>
            <button
              onClick={() => onNavigateTab('tools')}
              className="flex items-center space-x-1.5 p-1.5 rounded-xl bg-slate-800/40 dark:bg-slate-800/40 light:bg-slate-100 hover:bg-slate-800 text-[11px] font-medium text-slate-300 dark:text-slate-300 light:text-slate-700 transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              <span>8 Tools</span>
            </button>
            <button
              onClick={() => onNavigateTab('chats')}
              className="flex items-center space-x-1.5 p-1.5 rounded-xl bg-slate-800/40 dark:bg-slate-800/40 light:bg-slate-100 hover:bg-slate-800 text-[11px] font-medium text-slate-300 dark:text-slate-300 light:text-slate-700 transition-colors"
            >
              <MessageSquare className="w-3.5 h-3.5 text-indigo-400" />
              <span>History</span>
            </button>
          </div>
        </div>

        {/* Suggested Prompts Section */}
        <SuggestedPrompts onSelectPrompt={(prompt) => handleSend(prompt)} />
      </div>

      {/* Bottom Sticky Input Container on Home Screen */}
      <div className="w-full mt-4">
        <ChatInputBar
          onSend={handleSend}
          isGenerating={isGenerating}
          onStop={stopGeneration}
          placeholder="Ask BIJOY AI or upload an image..."
        />
        <div className="flex items-center justify-center space-x-4 mt-2 text-[10px] text-slate-400">
          <span className="flex items-center">
            <ShieldCheck className="w-3 h-3 mr-1 text-sky-400" /> End-to-End Encrypted
          </span>
          <span>•</span>
          <span>Bengali (বাংলা) & English Supported</span>
        </div>
      </div>
    </div>
  );
};
