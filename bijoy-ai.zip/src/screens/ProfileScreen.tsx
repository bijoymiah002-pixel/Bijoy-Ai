import React, { useState } from 'react';
import { useChat } from '../context/ChatContext';
import { useTheme } from '../context/ThemeContext';
import {
  User,
  Moon,
  Sun,
  Globe,
  Volume2,
  Sliders,
  Shield,
  Info,
  LogOut,
  Sparkles,
  Check,
  Zap,
  Cpu,
  ChevronRight,
  ExternalLink,
  Crown,
} from 'lucide-react';
import { BijoyLogo } from '../components/BijoyLogo';

export const ProfileScreen: React.FC<{
  onReplaySplash: () => void;
}> = ({ onReplaySplash }) => {
  const { userProfile, updateUserProfile, speakText, clearAllSessions } = useChat();
  const { theme, setTheme } = useTheme();

  const [isEditingName, setIsEditingName] = useState(false);
  const [tempName, setTempName] = useState(userProfile.name);
  const [showAboutModal, setShowAboutModal] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const handleSaveName = () => {
    if (tempName.trim()) {
      updateUserProfile({ name: tempName.trim() });
    }
    setIsEditingName(false);
  };

  const handleTestVoice = () => {
    speakText('Hello! This is BIJOY AI testing your selected voice synthesizer rate and pitch.');
  };

  return (
    <div className="flex flex-col min-h-[calc(100vh-130px)] pb-24 px-4 max-w-md mx-auto text-left">
      {/* Profile Header Card */}
      <div className="mt-2 p-4 rounded-3xl bg-gradient-to-br from-indigo-950/60 via-slate-900/80 to-[#0B0F19] border border-indigo-500/20 shadow-xl backdrop-blur-md relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-sky-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-center space-x-3.5">
          {/* User Avatar */}
          <div className="relative">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-sky-400 via-indigo-600 to-purple-600 p-0.5 shadow-lg">
              <div className="w-full h-full rounded-2xl bg-[#0B0F19] flex items-center justify-center overflow-hidden">
                <img
                  src={userProfile.avatar}
                  alt={userProfile.name}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            <div className="absolute -bottom-1 -right-1 bg-gradient-to-r from-amber-400 to-amber-600 p-1 rounded-full text-[#0B0F19]">
              <Crown className="w-3 h-3 fill-current" />
            </div>
          </div>

          {/* User Details */}
          <div className="flex-1 min-w-0">
            {isEditingName ? (
              <div className="flex items-center space-x-1.5">
                <input
                  type="text"
                  value={tempName}
                  onChange={(e) => setTempName(e.target.value)}
                  className="bg-slate-800 text-xs px-2 py-1 rounded-lg border border-sky-500 text-white outline-none"
                  autoFocus
                />
                <button
                  onClick={handleSaveName}
                  className="p-1 rounded-lg bg-sky-500 text-white"
                >
                  <Check className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-1.5">
                <h3 className="font-extrabold text-base text-slate-100 truncate">
                  {userProfile.name}
                </h3>
                <button
                  onClick={() => {
                    setTempName(userProfile.name);
                    setIsEditingName(true);
                  }}
                  className="text-[10px] text-sky-400 hover:underline"
                >
                  Edit
                </button>
              </div>
            )}
            <p className="text-xs text-slate-400 truncate">{userProfile.email}</p>
            <div className="flex items-center space-x-2 mt-1">
              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
                <Sparkles className="w-2.5 h-2.5 mr-1" /> {userProfile.membership}
              </span>
              <span className="text-[10px] text-emerald-400 flex items-center">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1 animate-pulse" /> Active
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Settings Sections */}
      <div className="mt-4 space-y-4">
        {/* Appearance Settings */}
        <div className="p-4 rounded-2xl bg-slate-900/60 dark:bg-slate-900/60 light:bg-slate-50 border border-slate-800 dark:border-slate-800 light:border-slate-200 shadow-sm">
          <div className="flex items-center space-x-2 mb-3">
            <Sun className="w-4 h-4 text-sky-400" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">
              Theme & Appearance
            </h4>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => setTheme('dark')}
              className={`p-3 rounded-xl border flex items-center justify-center space-x-2 text-xs font-semibold transition-all ${
                theme === 'dark'
                  ? 'bg-indigo-600/20 border-sky-500 text-sky-300 shadow-md'
                  : 'bg-slate-800/40 border-slate-800 text-slate-400'
              }`}
            >
              <Moon className="w-4 h-4 text-indigo-400" />
              <span>Dark Navy</span>
            </button>
            <button
              onClick={() => setTheme('light')}
              className={`p-3 rounded-xl border flex items-center justify-center space-x-2 text-xs font-semibold transition-all ${
                theme === 'light'
                  ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300 shadow-md'
                  : 'bg-slate-800/40 border-slate-800 text-slate-400'
              }`}
            >
              <Sun className="w-4 h-4 text-amber-400" />
              <span>Clean Light</span>
            </button>
          </div>
        </div>

        {/* Language Preference */}
        <div className="p-4 rounded-2xl bg-slate-900/60 dark:bg-slate-900/60 light:bg-slate-50 border border-slate-800 dark:border-slate-800 light:border-slate-200 shadow-sm">
          <div className="flex items-center space-x-2 mb-3">
            <Globe className="w-4 h-4 text-purple-400" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">
              Language Settings
            </h4>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 'auto', label: 'Auto Detect' },
              { id: 'en', label: 'English' },
              { id: 'bn', label: 'বাংলা (Bengali)' },
            ].map((lang) => (
              <button
                key={lang.id}
                onClick={() => updateUserProfile({ preferredLanguage: lang.id as any })}
                className={`py-2 px-2.5 rounded-xl border text-[11px] font-semibold text-center transition-all ${
                  userProfile.preferredLanguage === lang.id
                    ? 'bg-purple-600/20 border-purple-500 text-purple-300 shadow-sm'
                    : 'bg-slate-800/40 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {lang.label}
              </button>
            ))}
          </div>
        </div>

        {/* AI Persona Selection */}
        <div className="p-4 rounded-2xl bg-slate-900/60 dark:bg-slate-900/60 light:bg-slate-50 border border-slate-800 dark:border-slate-800 light:border-slate-200 shadow-sm">
          <div className="flex items-center space-x-2 mb-3">
            <Cpu className="w-4 h-4 text-cyan-400" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">
              AI Persona & Mode
            </h4>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            {[
              { id: 'balanced', label: 'Balanced & Smart', desc: 'Default Gemini 3.8 flow' },
              { id: 'creative', label: 'Creative & Vivid', desc: 'Story & content writing' },
              { id: 'precise', label: 'Concise & Direct', desc: 'Short bullet takeaways' },
              { id: 'coder', label: 'Coding Specialist', desc: 'Deep technical code & specs' },
            ].map((persona) => (
              <button
                key={persona.id}
                onClick={() => updateUserProfile({ systemPersona: persona.id as any })}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  userProfile.systemPersona === persona.id
                    ? 'bg-cyan-500/15 border-cyan-500 text-cyan-200 shadow-sm'
                    : 'bg-slate-800/40 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="font-semibold text-slate-200">{persona.label}</div>
                <div className="text-[10px] text-slate-500">{persona.desc}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Voice Synthesizer Settings */}
        <div className="p-4 rounded-2xl bg-slate-900/60 dark:bg-slate-900/60 light:bg-slate-50 border border-slate-800 dark:border-slate-800 light:border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <Volume2 className="w-4 h-4 text-emerald-400" />
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Voice & Speech
              </h4>
            </div>
            <button
              onClick={handleTestVoice}
              className="text-[11px] font-semibold text-sky-400 hover:underline flex items-center space-x-1"
            >
              <span>Test Voice</span>
            </button>
          </div>

          {/* Voice behavior info & on-demand readout */}
          <div className="flex items-center justify-between py-2 border-b border-slate-800">
            <div>
              <div className="text-xs font-semibold text-slate-200">Voice Playback Mode</div>
              <div className="text-[10px] text-slate-400">Text-only by default • Tap 🔊 on any message to listen</div>
            </div>
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-sky-500/15 text-sky-400 border border-sky-500/30">
              On-Demand
            </span>
          </div>

          {/* Speech Rate Slider */}
          <div className="pt-3">
            <div className="flex justify-between text-xs text-slate-300 mb-1">
              <span>Speech Speed</span>
              <span className="font-mono text-sky-400">{userProfile.speechRate}x</span>
            </div>
            <input
              type="range"
              min="0.75"
              max="1.5"
              step="0.05"
              value={userProfile.speechRate}
              onChange={(e) => updateUserProfile({ speechRate: parseFloat(e.target.value) })}
              className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
            />
          </div>
        </div>

        {/* General Actions */}
        <div className="space-y-2">
          {/* Replay Splash Screen */}
          <button
            onClick={onReplaySplash}
            className="w-full p-3.5 rounded-2xl bg-slate-900/60 hover:bg-slate-800/80 border border-slate-800 text-xs font-semibold text-slate-300 flex items-center justify-between transition-colors"
          >
            <div className="flex items-center space-x-2.5">
              <Sparkles className="w-4 h-4 text-sky-400" />
              <span>Show Splash Animation Again</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          {/* About BIJOY AI */}
          <button
            onClick={() => setShowAboutModal(true)}
            className="w-full p-3.5 rounded-2xl bg-slate-900/60 hover:bg-slate-800/80 border border-slate-800 text-xs font-semibold text-slate-300 flex items-center justify-between transition-colors"
          >
            <div className="flex items-center space-x-2.5">
              <Info className="w-4 h-4 text-purple-400" />
              <span>About BIJOY AI & Specs</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          {/* Reset / Clear Data */}
          {showResetConfirm ? (
            <div className="p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-xs space-y-2">
              <div className="font-semibold text-rose-300">
                Are you sure you want to reset all data and conversations?
              </div>
              <div className="flex items-center justify-end space-x-2">
                <button
                  onClick={() => setShowResetConfirm(false)}
                  className="px-3 py-1 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    clearAllSessions();
                    setShowResetConfirm(false);
                  }}
                  className="px-3 py-1 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold"
                >
                  Confirm Reset
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => setShowResetConfirm(true)}
              className="w-full p-3.5 rounded-2xl bg-slate-900/60 hover:bg-rose-950/20 border border-slate-800 hover:border-rose-900/40 text-xs font-semibold text-rose-400 flex items-center justify-between transition-colors"
            >
              <div className="flex items-center space-x-2.5">
                <LogOut className="w-4 h-4" />
                <span>Reset Application & Storage</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-500" />
            </button>
          )}
        </div>
      </div>

      {/* About Modal */}
      {showAboutModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade-in">
          <div className="w-full max-w-sm bg-[#0B0F19] border border-slate-700 rounded-3xl p-6 shadow-2xl text-center space-y-4">
            <BijoyLogo size={60} animated={true} withGlow={true} className="mx-auto" />

            <div>
              <h3 className="text-lg font-black text-slate-100">BIJOY AI</h3>
              <p className="text-xs text-sky-400 font-semibold">Your Smart AI Assistant</p>
              <p className="text-[11px] text-slate-400 mt-1">Version 2.5 Mobile Pro Edition</p>
            </div>

            <div className="bg-slate-900 p-3 rounded-2xl border border-slate-800 text-left text-xs space-y-1.5 text-slate-300">
              <div>🤖 <strong>Engine:</strong> Google Gemini 3.8 Flash</div>
              <div>⚡ <strong>Architecture:</strong> Express Backend + React 19 + Tailwind v4</div>
              <div>🎙️ <strong>Voice:</strong> Web Speech Synthesizer & Recognition</div>
              <div>🌐 <strong>Languages:</strong> Bengali (বাংলা) & English</div>
              <div>🛡️ <strong>Owner:</strong> Bijoy Miah</div>
            </div>

            <button
              onClick={() => setShowAboutModal(false)}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 text-white text-xs font-bold"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
