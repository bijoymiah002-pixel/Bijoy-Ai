import React, { useState } from 'react';
import {
  PenTool,
  Languages,
  FileText,
  Code,
  CheckCheck,
  Mail,
  GraduationCap,
  Calculator,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  Copy,
  Check,
  RotateCcw,
  Volume2,
  VolumeX,
  ExternalLink,
  X,
  Send,
  RefreshCw,
  AlertCircle,
  Lightbulb,
  SlidersHorizontal,
} from 'lucide-react';
import { ToolId, AIToolConfig } from '../types';
import { MarkdownRenderer } from '../components/MarkdownRenderer';
import { useChat } from '../context/ChatContext';

export interface ToolDefinition extends AIToolConfig {
  category: 'content' | 'coding' | 'language' | 'academic';
  customControls?: Array<{
    id: string;
    label: string;
    bengaliLabel: string;
    type: 'select' | 'chips';
    choices: string[];
    default: string;
  }>;
}

const EXTENDED_TOOLS: ToolDefinition[] = [
  {
    id: 'writer',
    name: 'AI Writer',
    bengaliName: 'এআই লেখক',
    category: 'content',
    description: 'Generate high-impact articles, stories, blog posts, essays, and creative content.',
    icon: 'PenTool',
    badge: 'Creative & Pro',
    gradient: 'from-amber-500 to-orange-600',
    placeholder: 'Enter topic, key points, or instructions for your article, story or post...',
    options: [
      {
        label: 'Content Type',
        key: 'type',
        choices: ['Article', 'Blog Post', 'Creative Story', 'Social Media Post', 'Essay', 'Speech Script'],
        default: 'Article',
      },
      {
        label: 'Tone',
        key: 'tone',
        choices: ['Professional & Engaging', 'Creative & Vivid', 'Casual & Friendly', 'Inspirational', 'Persuasive'],
        default: 'Professional & Engaging',
      },
      {
        label: 'Language',
        key: 'language',
        choices: ['English', 'Bengali (বাংলা)', 'Auto-detect'],
        default: 'English',
      },
      {
        label: 'Length',
        key: 'length',
        choices: ['Short (~300 words)', 'Medium (~600 words)', 'In-depth (~1000+ words)'],
        default: 'Medium (~600 words)',
      },
    ],
    sampleInputs: [
      'The impact of Artificial Intelligence on the future of healthcare and medicine',
      'একটি সুন্দর অনুপ্রেরণামূলক গল্প যা মানুষকে ধৈর্য ও কঠোর পরিশ্রমের গুরুত্ব শেখায়',
      'The pros and cons of remote work vs hybrid office models for software engineers',
    ],
  },
  {
    id: 'translator',
    name: 'AI Translator',
    bengaliName: 'এআই অনুবাদক',
    category: 'language',
    description: 'Accurately translate text between Bengali, English and global languages.',
    icon: 'Languages',
    badge: 'Bilingual Pro',
    gradient: 'from-emerald-500 to-teal-600',
    placeholder: 'Paste the text you want to translate here...',
    options: [
      {
        label: 'Translate From',
        key: 'sourceLang',
        choices: ['Auto-Detect', 'English', 'Bengali (বাংলা)', 'Spanish', 'French', 'Arabic', 'Hindi', 'German', 'Japanese'],
        default: 'Auto-Detect',
      },
      {
        label: 'Translate To',
        key: 'targetLang',
        choices: ['Bengali (বাংলা)', 'English', 'Spanish', 'Arabic', 'Hindi', 'French', 'German', 'Japanese'],
        default: 'Bengali (বাংলা)',
      },
      {
        label: 'Formality',
        key: 'formality',
        choices: ['Natural & Professional', 'Conversational / Friendly', 'Formal / Business', 'Literary / Poetic'],
        default: 'Natural & Professional',
      },
    ],
    sampleInputs: [
      'Technology gives us the ability to connect across oceans and share ideas in real time.',
      'কৃত্রিম বুদ্ধিমত্তা মানুষের জীবনযাত্রাকে সহজ, দ্রুত এবং গতিশীল করে তুলছে।',
      'Good morning Bijoy! Looking forward to reviewing the latest project milestones today.',
    ],
  },
  {
    id: 'summarizer',
    name: 'AI Summarizer',
    bengaliName: 'এআই সারসংক্ষেপ',
    category: 'content',
    description: 'Summarize long text, articles, research papers and meeting notes into clear explanations.',
    icon: 'FileText',
    badge: 'Executive',
    gradient: 'from-blue-500 to-indigo-600',
    placeholder: 'Paste long article, meeting notes, research paper, or document text here...',
    options: [
      {
        label: 'Summary Format',
        key: 'format',
        choices: ['Key Bullet Points', 'Executive TL;DR', 'Structured Q&A Breakdown', 'One-Sentence Punchline'],
        default: 'Key Bullet Points',
      },
      {
        label: 'Depth',
        key: 'length',
        choices: ['Concise (Quick Takeaways)', 'Balanced Summary', 'Detailed Analysis'],
        default: 'Balanced Summary',
      },
      {
        label: 'Output Language',
        key: 'language',
        choices: ['Same as Input', 'English', 'Bengali (বাংলা)'],
        default: 'Same as Input',
      },
    ],
    sampleInputs: [
      'The rapid expansion of electric vehicles has led to unprecedented global demand for battery manufacturing, lithium supply chains, and clean energy grid upgrades across continents...',
      'Deep learning models rely on deep multi-layered neural networks trained on vast amounts of dataset tokens to detect patterns and generate human-like predictions with probabilistic accuracy...',
    ],
  },
  {
    id: 'coder',
    name: 'Coding Assistant',
    bengaliName: 'কোডিং সহকারী',
    category: 'coding',
    description: 'Write clean code, debug syntax errors, explain algorithms and optimize performance.',
    icon: 'Code',
    badge: 'Full-Stack',
    gradient: 'from-cyan-500 to-blue-600',
    placeholder: 'Describe your function, bug, algorithm or paste code snippet to analyze...',
    options: [
      {
        label: 'Programming Language',
        key: 'language',
        choices: ['TypeScript / React', 'Python', 'JavaScript (Node.js)', 'Java', 'C++', 'Go', 'PHP', 'SQL', 'Rust'],
        default: 'TypeScript / React',
      },
      {
        label: 'Action Task',
        key: 'task',
        choices: ['Write Code from Scratch', 'Debug & Fix Errors', 'Explain Code Line-by-Line', 'Optimize & Refactor', 'Generate Unit Tests'],
        default: 'Write Code from Scratch',
      },
      {
        label: 'Explanation Language',
        key: 'lang',
        choices: ['English', 'Bengali (বাংলা)'],
        default: 'English',
      },
    ],
    sampleInputs: [
      'Create a debounce custom hook in React with TypeScript and automatic timeout cleanup',
      'Write an efficient Python function to solve the Two Sum problem in O(n) time using a hash map',
      'Explain how the JavaScript Event Loop, Microtask Queue and Promises work under the hood',
    ],
  },
  {
    id: 'grammar',
    name: 'Grammar Checker',
    bengaliName: 'ব্যাকরণ সংশোধক',
    category: 'language',
    description: 'Detect and correct grammatical mistakes, spelling, punctuation and improve sentence fluency.',
    icon: 'CheckCheck',
    badge: 'Proofreader',
    gradient: 'from-purple-500 to-pink-600',
    placeholder: 'Paste your draft text for instant error detection and professional correction...',
    options: [
      {
        label: 'Correction Level',
        key: 'level',
        choices: ['Fix Grammar & Spelling Only', 'Grammar + Better Vocabulary', 'Executive Professional Polish'],
        default: 'Grammar + Better Vocabulary',
      },
      {
        label: 'Target Language',
        key: 'language',
        choices: ['Auto-Detect', 'English', 'Bengali (বাংলা)'],
        default: 'Auto-Detect',
      },
    ],
    sampleInputs: [
      'Me and him goes to the office yesterday and we was talking about new projects.',
      'I am write this email to let you know that I am interested in this job position very much.',
      'আমরা গতকালকে মিটিংয়ে গেছিলাম এবং প্রজেক্টের সব বিষয় নিয়ে কথপোকথন সম্পন্ন হয়েছে।',
    ],
  },
  {
    id: 'email',
    name: 'Email Writer',
    bengaliName: 'ইমেইল রাইটার',
    category: 'content',
    description: 'Create professional emails for business proposals, job applications, inquiries and follow-ups.',
    icon: 'Mail',
    badge: 'Business',
    gradient: 'from-rose-500 to-red-600',
    placeholder: 'What is the purpose of this email? Mention recipient, key points and any required deadlines...',
    options: [
      {
        label: 'Email Purpose',
        key: 'purpose',
        choices: ['Client Project Proposal', 'Job Application / Cover Note', 'Meeting Follow-up', 'Polite Payment Reminder', 'Leave / Absence Request', 'Networking Introduction'],
        default: 'Client Project Proposal',
      },
      {
        label: 'Tone',
        key: 'tone',
        choices: ['Professional & Courteous', 'Confident & Direct', 'Warm & Friendly', 'Urgent but Polite'],
        default: 'Professional & Courteous',
      },
      {
        label: 'Language',
        key: 'language',
        choices: ['English', 'Bengali (বাংলা)'],
        default: 'English',
      },
    ],
    sampleInputs: [
      'Pitching custom web application development services to a tech startup founder',
      'Following up after an interview for a Senior Full-Stack Engineer position',
      'Requesting a project deadline extension of 3 days due to third-party API dependencies',
    ],
  },
  {
    id: 'study',
    name: 'Study Assistant',
    bengaliName: 'স্টাডি অ্যাসিস্ট্যান্ট',
    category: 'academic',
    description: 'Explain educational topics, generate flashcards, create quizzes and answer learning questions.',
    icon: 'GraduationCap',
    badge: 'Academic',
    gradient: 'from-violet-500 to-indigo-700',
    placeholder: 'Enter a topic, chapter name, or academic question you want to study and master...',
    options: [
      {
        label: 'Study Mode',
        key: 'mode',
        choices: ['Detailed Concept Explanation', 'Quiz Generator (3 Questions + Answers)', 'Active Recall Flashcards', 'Mnemonics & Memory Hacks'],
        default: 'Detailed Concept Explanation',
      },
      {
        label: 'Target Level',
        key: 'level',
        choices: ['High School / Beginner', 'College / University', 'Explain Like I am 10', 'Advanced Professional'],
        default: 'College / University',
      },
      {
        label: 'Language',
        key: 'language',
        choices: ['English', 'Bengali (বাংলা)'],
        default: 'English',
      },
    ],
    sampleInputs: [
      'How does photosynthesis work in plants and what are light-dependent reactions?',
      'The law of supply and demand and price elasticity in microeconomics',
      'Newton’s three laws of motion with real-world examples in daily life',
    ],
  },
  {
    id: 'math',
    name: 'Math Assistant',
    bengaliName: 'গণিত সহকারী',
    category: 'academic',
    description: 'Solve mathematical problems with step-by-step formulas, derivations and explanations.',
    icon: 'Calculator',
    badge: 'STEM Solver',
    gradient: 'from-amber-600 to-yellow-500',
    placeholder: 'Type your math problem, formula, algebraic equation or calculus question...',
    options: [
      {
        label: 'Math Topic',
        key: 'topic',
        choices: ['General Algebra', 'Calculus & Derivatives', 'Geometry & Trigonometry', 'Probability & Statistics', 'Linear Algebra / Matrices', 'Arithmetic'],
        default: 'General Algebra',
      },
      {
        label: 'Solution Style',
        key: 'depth',
        choices: ['Detailed Step-by-Step Derivation', 'Quick Final Answer + Check', 'Intuitive Proof with Graphs'],
        default: 'Detailed Step-by-Step Derivation',
      },
      {
        label: 'Language',
        key: 'language',
        choices: ['English', 'Bengali (বাংলা)'],
        default: 'English',
      },
    ],
    sampleInputs: [
      'Solve the quadratic equation: 3x^2 - 12x + 9 = 0',
      'Find the derivative of f(x) = (3x^2 + 5x) * e^(2x)',
      'Calculate the area of a triangle with sides a=7, b=8, and c=9 using Heron’s formula',
    ],
  },
];

export const ToolsScreen: React.FC<{
  onStartChatWithPrompt: (prompt: string) => void;
}> = ({ onStartChatWithPrompt }) => {
  const { speakText, stopSpeaking, isSpeaking } = useChat();

  const [activeTool, setActiveTool] = useState<ToolDefinition | null>(null);
  const [toolInput, setToolInput] = useState('');
  const [selectedOptions, setSelectedOptions] = useState<Record<string, string>>({});
  const [isExecuting, setIsExecuting] = useState(false);
  const [toolResult, setToolResult] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [speakingResult, setSpeakingResult] = useState(false);
  const [activeCategory, setActiveCategory] = useState<'all' | 'content' | 'coding' | 'language' | 'academic'>('all');

  const getIcon = (name: string, className = 'w-5 h-5') => {
    switch (name) {
      case 'PenTool':
        return <PenTool className={className} />;
      case 'Languages':
        return <Languages className={className} />;
      case 'FileText':
        return <FileText className={className} />;
      case 'Code':
        return <Code className={className} />;
      case 'CheckCheck':
        return <CheckCheck className={className} />;
      case 'Mail':
        return <Mail className={className} />;
      case 'GraduationCap':
        return <GraduationCap className={className} />;
      case 'Calculator':
        return <Calculator className={className} />;
      default:
        return <Sparkles className={className} />;
    }
  };

  const openToolInterface = (tool: ToolDefinition) => {
    setActiveTool(tool);
    setToolInput('');
    setToolResult(null);
    setErrorMessage(null);

    // Initialize options with defaults
    const defaults: Record<string, string> = {};
    tool.options.forEach((opt) => {
      defaults[opt.key] = opt.default;
    });
    setSelectedOptions(defaults);
  };

  const handleRunTool = async () => {
    if (!toolInput.trim() || !activeTool || isExecuting) return;

    setIsExecuting(true);
    setToolResult(null);
    setErrorMessage(null);

    try {
      const res = await fetch('/api/tools/execute', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          toolId: activeTool.id,
          input: toolInput.trim(),
          options: selectedOptions,
        }),
      });

      const data = await res.json();
      if (res.ok && data.result) {
        setToolResult(data.result);
      } else {
        setErrorMessage(data.error || 'Failed to generate output. Please check your query and try again.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Network error connecting to Gemini API.');
    } finally {
      setIsExecuting(false);
    }
  };

  const handleCopyResult = () => {
    if (!toolResult) return;
    navigator.clipboard.writeText(toolResult);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleToggleSpeak = () => {
    if (!toolResult) return;
    if (isSpeaking && speakingResult) {
      stopSpeaking();
      setSpeakingResult(false);
    } else {
      stopSpeaking();
      speakText(toolResult);
      setSpeakingResult(true);
    }
  };

  const filteredTools = EXTENDED_TOOLS.filter(
    (t) => activeCategory === 'all' || t.category === activeCategory
  );

  return (
    <div className="flex flex-col min-h-[calc(100vh-130px)] pb-24 px-4 max-w-md mx-auto text-left">
      {/* View 1: Main AI Tools Dashboard */}
      {!activeTool ? (
        <div className="animate-fade-in space-y-4">
          {/* Header */}
          <div className="pt-2 text-left">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-sky-400 animate-pulse" />
              <h2 className="text-xl font-black tracking-tight text-slate-100">
                AI Tools Suite
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              8 fully-functional intelligence engines powered by Google Gemini API
            </p>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
            {[
              { id: 'all', label: 'All Tools' },
              { id: 'content', label: 'Writing' },
              { id: 'coding', label: 'Coding' },
              { id: 'language', label: 'Languages' },
              { id: 'academic', label: 'Study & Math' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id as any)}
                className={`px-3 py-1.5 rounded-xl font-semibold transition-all whitespace-nowrap ${
                  activeCategory === cat.id
                    ? 'bg-sky-500/20 text-sky-400 border border-sky-500/40 shadow-sm'
                    : 'bg-slate-900/60 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Grid of 8 Tools */}
          <div className="grid grid-cols-2 gap-3 pt-1">
            {filteredTools.map((tool) => (
              <button
                key={tool.id}
                onClick={() => openToolInterface(tool)}
                className="flex flex-col text-left p-3.5 rounded-2xl bg-[#0F172A]/85 dark:bg-[#0F172A]/85 light:bg-slate-50 hover:bg-slate-800/90 dark:hover:bg-slate-800/90 light:hover:bg-slate-100 border border-slate-800 dark:border-slate-800 light:border-slate-200 hover:border-sky-500/50 shadow-sm transition-all duration-200 active:scale-95 group relative overflow-hidden"
              >
                <div
                  className={`w-9 h-9 rounded-xl bg-gradient-to-tr ${tool.gradient} text-white flex items-center justify-center shadow-md mb-2.5 group-hover:scale-105 transition-transform`}
                >
                  {getIcon(tool.icon)}
                </div>

                <div className="flex items-center justify-between w-full">
                  <span className="font-bold text-xs text-slate-100 group-hover:text-sky-300 transition-colors">
                    {tool.name}
                  </span>
                  <span className="text-[9px] font-semibold px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-400">
                    {tool.badge}
                  </span>
                </div>

                <span className="text-[10px] text-purple-400 font-medium mt-0.5">
                  {tool.bengaliName}
                </span>

                <p className="text-[11px] text-slate-400 line-clamp-2 mt-1 leading-snug">
                  {tool.description}
                </p>

                <div className="flex items-center space-x-1 text-[10px] font-semibold text-sky-400 mt-2.5 opacity-90 group-hover:translate-x-0.5 transition-transform">
                  <span>Open Tool</span>
                  <ArrowRight className="w-3 h-3" />
                </div>
              </button>
            ))}
          </div>
        </div>
      ) : (
        /* View 2: Dedicated Tool Interface */
        <div className="animate-fade-in space-y-4 pt-1">
          {/* Tool Navigation Bar */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <button
              onClick={() => setActiveTool(null)}
              className="flex items-center space-x-1 text-xs font-semibold text-slate-400 hover:text-sky-400 transition-colors px-2 py-1 rounded-xl bg-slate-900/80 border border-slate-800"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>All Tools</span>
            </button>

            <div className="flex items-center space-x-2">
              <div
                className={`w-7 h-7 rounded-xl bg-gradient-to-tr ${activeTool.gradient} text-white flex items-center justify-center shadow-sm`}
              >
                {getIcon(activeTool.icon, 'w-4 h-4')}
              </div>
              <div className="text-right">
                <span className="font-extrabold text-xs text-slate-100">
                  {activeTool.name}
                </span>
                <span className="text-[10px] text-purple-400 block -mt-0.5">
                  {activeTool.bengaliName}
                </span>
              </div>
            </div>
          </div>

          {/* Description & Instruction Banner */}
          <div className="p-3 rounded-2xl bg-slate-900/60 border border-slate-800 text-xs text-slate-300 flex items-start space-x-2.5">
            <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div className="leading-relaxed text-[11.5px]">
              {activeTool.description}
            </div>
          </div>

          {/* Tool Options Configuration Box */}
          {activeTool.options.length > 0 && (
            <div className="p-3.5 rounded-2xl bg-[#0F172A]/90 border border-slate-800 space-y-2.5 shadow-sm">
              <div className="flex items-center space-x-1.5 text-xs font-bold text-slate-300 uppercase tracking-wide">
                <SlidersHorizontal className="w-3.5 h-3.5 text-sky-400" />
                <span>Tool Settings & Parameters</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                {activeTool.options.map((opt) => (
                  <div key={opt.key} className="flex flex-col space-y-1">
                    <label className="text-[11px] font-semibold text-slate-400">
                      {opt.label}:
                    </label>
                    <select
                      value={selectedOptions[opt.key] || opt.default}
                      onChange={(e) =>
                        setSelectedOptions({
                          ...selectedOptions,
                          [opt.key]: e.target.value,
                        })
                      }
                      className="bg-slate-900 text-slate-200 text-xs rounded-xl px-2.5 py-1.5 border border-slate-700 outline-none focus:border-sky-500 transition-colors"
                    >
                      {opt.choices.map((c) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                    </select>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Quick Clickable Sample Prompts */}
          <div className="space-y-1.5">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Quick Preset Prompts:
            </span>
            <div className="flex flex-col space-y-1.5">
              {activeTool.sampleInputs.map((sample, idx) => (
                <button
                  key={idx}
                  onClick={() => setToolInput(sample)}
                  className="text-left text-[11px] text-sky-300/90 bg-sky-950/25 hover:bg-sky-950/50 p-2 rounded-xl border border-sky-900/40 transition-colors truncate flex items-center space-x-1.5"
                >
                  <span className="text-sky-400">💡</span>
                  <span className="truncate">{sample}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Text Input Area */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-bold text-slate-300">
                Input Text & Instructions:
              </label>
              {toolInput && (
                <button
                  onClick={() => setToolInput('')}
                  className="text-[10px] text-slate-400 hover:text-rose-400 transition-colors"
                >
                  Clear Input
                </button>
              )}
            </div>
            <textarea
              value={toolInput}
              onChange={(e) => setToolInput(e.target.value)}
              placeholder={activeTool.placeholder}
              rows={4}
              className="w-full rounded-2xl bg-slate-900 text-slate-100 placeholder:text-slate-500 text-xs p-3.5 border border-slate-700/80 outline-none focus:border-sky-500 leading-relaxed resize-none shadow-inner"
            />
          </div>

          {/* Primary Generate Button */}
          <button
            onClick={handleRunTool}
            disabled={!toolInput.trim() || isExecuting}
            className={`w-full py-3 rounded-2xl font-bold text-xs flex items-center justify-center space-x-2 transition-all shadow-lg active:scale-95 ${
              toolInput.trim() && !isExecuting
                ? `bg-gradient-to-r ${activeTool.gradient} text-white hover:opacity-95 shadow-[0_0_20px_rgba(56,189,248,0.3)] cursor-pointer`
                : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
            }`}
          >
            {isExecuting ? (
              <>
                <span className="w-4 h-4 rounded-full border-2 border-white border-t-transparent animate-spin" />
                <span>Processing with Gemini API...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Generate Result with {activeTool.name}</span>
              </>
            )}
          </button>

          {/* Error Message Banner */}
          {errorMessage && (
            <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start space-x-2 animate-fade-in">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div className="flex-1">
                <span className="font-semibold block">Generation Error:</span>
                <span className="text-[11px]">{errorMessage}</span>
                <button
                  onClick={handleRunTool}
                  className="mt-1 text-[11px] font-bold text-rose-400 hover:underline block"
                >
                  Click to Retry
                </button>
              </div>
            </div>
          )}

          {/* Generated Result Output */}
          {toolResult && (
            <div className="mt-3 p-4 rounded-3xl bg-[#0B0F19] border border-indigo-500/40 text-xs space-y-3 shadow-xl animate-fade-in">
              {/* Output Action Header */}
              <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
                <span className="font-bold text-sky-400 flex items-center space-x-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                  <span>AI Result</span>
                </span>

                <div className="flex items-center space-x-1.5">
                  {/* Regenerate Button */}
                  <button
                    onClick={handleRunTool}
                    disabled={isExecuting}
                    title="Regenerate Output"
                    className="flex items-center space-x-1 px-2.5 py-1 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-sky-300 text-[11px] font-medium border border-slate-700 transition-colors"
                  >
                    <RotateCcw className={`w-3 h-3 ${isExecuting ? 'animate-spin' : ''}`} />
                    <span>Regenerate</span>
                  </button>

                  {/* Copy Button */}
                  <button
                    onClick={handleCopyResult}
                    title="Copy to Clipboard"
                    className="flex items-center space-x-1 px-2.5 py-1 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white text-[11px] font-medium border border-slate-700 transition-colors"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" />
                        <span className="text-emerald-400">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>

                  {/* On-demand TTS Voice readout */}
                  <button
                    onClick={handleToggleSpeak}
                    className={`p-1.5 rounded-xl border transition-colors ${
                      isSpeaking && speakingResult
                        ? 'bg-sky-500/20 text-sky-300 border-sky-500/50'
                        : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300 border-slate-700'
                    }`}
                    title={isSpeaking && speakingResult ? 'Stop Voice' : 'Listen'}
                  >
                    {isSpeaking && speakingResult ? (
                      <VolumeX className="w-3.5 h-3.5 text-rose-400" />
                    ) : (
                      <Volume2 className="w-3.5 h-3.5 text-sky-400" />
                    )}
                  </button>
                </div>
              </div>

              {/* Formatted Markdown Content */}
              <div className="max-h-80 overflow-y-auto leading-relaxed">
                <MarkdownRenderer content={toolResult} />
              </div>

              {/* Continue in Main Chat Option */}
              <button
                onClick={() => {
                  onStartChatWithPrompt(`Tool Result from ${activeTool.name}:\n\n${toolResult}\n\nCan you expand, refine, or explain this further?`);
                  setActiveTool(null);
                }}
                className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-sky-300 text-xs font-semibold flex items-center justify-center space-x-1.5 transition-colors shadow-sm"
              >
                <span>Continue this in Main Chat</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
